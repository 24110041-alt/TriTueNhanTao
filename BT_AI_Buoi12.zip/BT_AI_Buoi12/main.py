'''https://github.com/24110041-alt'''
import tkinter as tk
from tkinter import scrolledtext
import threading
from algorithms import run_backtracking, run_forward_checking

# ==========================================
# CẤU HÌNH DỮ LIỆU
# ==========================================
danh_sach_phuong = [
    'Tân Định', 'Sài Gòn', 'Bến Thành', 'Cầu Ông Lãnh',
    'Võ Thị Sáu', 'Phường 2', 'Phường 9'
]

mau_sac = ['#FF4C4C', '#4CFF4C', '#FFD700'] 
ten_mau = {'#FF4C4C': 'Đỏ', '#4CFF4C': 'Xanh lá', '#FFD700': 'Vàng'}

ke_nhau = {
    'Tân Định': ['Võ Thị Sáu', 'Phường 2', 'Bến Thành', 'Sài Gòn'],
    'Sài Gòn': ['Tân Định', 'Phường 2', 'Bến Thành', 'Cầu Ông Lãnh', 'Phường 9'],
    'Bến Thành': ['Võ Thị Sáu', 'Tân Định', 'Sài Gòn', 'Cầu Ông Lãnh'],
    'Võ Thị Sáu': ['Tân Định', 'Bến Thành'],
    'Phường 2': ['Tân Định', 'Sài Gòn'],
    'Cầu Ông Lãnh': ['Bến Thành', 'Sài Gòn', 'Phường 9'],
    'Phường 9': ['Cầu Ông Lãnh', 'Sài Gòn']
}

toado_bando = {
    'Võ Thị Sáu': [50, 50, 180, 50, 200, 150, 50, 150],
    'Tân Định': [180, 50, 350, 50, 350, 150, 200, 150],
    'Phường 2': [350, 50, 500, 50, 450, 150, 350, 150],
    'Bến Thành': [50, 150, 200, 150, 250, 250, 50, 250],
    'Sài Gòn': [200, 150, 450, 150, 400, 250, 250, 250],
    'Cầu Ông Lãnh': [50, 250, 250, 250, 200, 350, 50, 350],
    'Phường 9': [250, 250, 400, 250, 450, 350, 200, 350]
}

toado_chu = {
    'Võ Thị Sáu': (120, 100), 'Tân Định': (260, 100), 'Phường 2': (420, 100),
    'Bến Thành': (150, 200), 'Sài Gòn': (320, 200), 'Cầu Ông Lãnh': (150, 300), 'Phường 9': (330, 300)
}

# ==========================================
# GIAO DIỆN
# ==========================================
root = tk.Tk()
root.title("Map Coloring CSP Simulation")
root.geometry("1100x550")

menu_frame = tk.Frame(root, width=200, bg="#f0f0f0", padx=10, pady=10)
menu_frame.pack(side=tk.LEFT, fill=tk.Y)
menu_frame.pack_propagate(False) 

algo_var = tk.IntVar(value=1)
tk.Label(menu_frame, text="THUẬT TOÁN", font=("Arial", 12, "bold"), bg="#f0f0f0").pack(pady=10)
tk.Radiobutton(menu_frame, text="Backtracking", variable=algo_var, value=1, bg="#f0f0f0").pack(anchor=tk.W)
tk.Radiobutton(menu_frame, text="Forward Checking", variable=algo_var, value=2, bg="#f0f0f0").pack(anchor=tk.W)

btn_start = tk.Button(menu_frame, text="▶ BẮT ĐẦU", bg="#4CAF50", fg="white", font=("Arial", 10, "bold"),
                      command=lambda: threading.Thread(target=thuat_toan_chay_ngam, daemon=True).start())
btn_start.pack(fill=tk.X, pady=30)

canvas = tk.Canvas(root, bg="white")
canvas.pack(side=tk.LEFT, expand=True, fill=tk.BOTH, padx=10, pady=20)
shapes = {p: canvas.create_polygon(toado_bando[p], outline='black', fill='white', width=2) for p in danh_sach_phuong}
for p in danh_sach_phuong: canvas.create_text(toado_chu[p], text=p, font=("Arial", 9, "bold"))

log_box = scrolledtext.ScrolledText(root, width=40, bg="white", fg="black", font=("Arial", 10))
log_box.pack(side=tk.RIGHT, fill=tk.Y, padx=10, pady=10)

def update_gui(p, c, t):
    # 1. In log bước hiện tại
    log_box.insert(tk.END, f"> {t}\n")
    
    # 2. Gạch ngang kết thúc vùng nếu xử lý xong
    if "Hợp lệ" in t or "Backtrack" in t or "cạn Domain" in t:
        log_box.insert(tk.END, "-------------------------------------------\n")
        
    # 3. Cập nhật bản đồ
    if p != 'white': 
        canvas.itemconfig(shapes[p], fill=c)
        
    log_box.see(tk.END)
    root.update_idletasks()

def thuat_toan_chay_ngam():
    btn_start.config(state=tk.DISABLED); log_box.delete('1.0', tk.END)
    for p in danh_sach_phuong: canvas.itemconfig(shapes[p], fill='white')
    if algo_var.get() == 1: 
        run_backtracking(danh_sach_phuong, mau_sac, ten_mau, ke_nhau, {}, update_gui)
    else: 
        domains = {p: mau_sac.copy() for p in danh_sach_phuong}
        run_forward_checking(danh_sach_phuong, mau_sac, ten_mau, ke_nhau, {}, domains, update_gui)
    btn_start.config(state=tk.NORMAL)

root.mainloop()