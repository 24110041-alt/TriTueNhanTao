import tkinter as tk
from caro_base import CaroBase

class CaroExpectimax(CaroBase):
    def __init__(self, root):
        super().__init__(root, title="Thuật toán Expectimax (X vs Random)")

    def expectimax(self, depth, is_maximizing):
        winner = self.check_winner()
        if winner == 'X': return 10 - depth
        if winner == 'O': return depth - 10
        if winner == 'Tie': return 0

        empty_cells = [i for i, v in enumerate(self.board) if v == ' ']

        if is_maximizing: # Nút Max (Lượt của X)
            max_eval = -float('inf')
            for i in empty_cells:
                self.board[i] = 'X'
                max_eval = max(max_eval, self.expectimax(depth + 1, False))
                self.board[i] = ' '
            return max_eval
        else: # Nút Chance (Lượt của O - Tính trung bình)
            total_eval = 0
            for i in empty_cells:
                self.board[i] = 'O'
                total_eval += self.expectimax(depth + 1, True)
                self.board[i] = ' '
            return total_eval / len(empty_cells)

    def play_turn(self):
        winner = self.check_winner()
        if winner:
            self.result_label.config(text=f"Kết thúc: {winner if winner != 'Tie' else 'Hòa!'}", fg='green')
            return

        self.log(f"--- Đến lượt {self.turn} (Expectimax) ---")
        move = -1
        
        if self.turn == 'X':
            best_score = -float('inf')
            for i in range(9):
                if self.board[i] == ' ':
                    self.board[i] = 'X'
                    score = self.expectimax(0, False)
                    self.board[i] = ' '
                    self.log(f" * X nhắm ô {i}: Trọng số kỳ vọng {score:.2f}")
                    if score > best_score:
                        best_score, move = score, i
        else:
            best_score = float('inf')
            for i in range(9):
                if self.board[i] == ' ':
                    self.board[i] = 'O'
                    score = self.expectimax(0, True)
                    self.board[i] = ' '
                    self.log(f" * O nhắm ô {i}: Trọng số kỳ vọng {score:.2f}")
                    if score < best_score:
                        best_score, move = score, i
        
        self.board[move] = self.turn
        self.buttons[move].config(text=self.turn, fg='blue' if self.turn == 'X' else 'red')
        self.log(f">> {self.turn} chốt ô {move} (Điểm: {best_score:.2f})\n")
        
        self.turn = 'O' if self.turn == 'X' else 'X'
        self.root.after(800, self.play_turn)

if __name__ == "__main__":
    root = tk.Tk()
    app = CaroExpectimax(root)
    root.mainloop()