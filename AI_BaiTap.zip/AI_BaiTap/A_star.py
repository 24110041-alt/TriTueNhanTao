#H(N) k/c manhattan + G(N) số dãy ngc
import copy
import heapq

START_BOARD = [
    ["X", "1", "1"],
    ["0", "1", "0"],
    ["0", "0", "0"]
]

class NodeAStar:
    def __init__(self, board, parent=None, action=None, path_cost=0):
        self.board = board
        self.parent = parent
        self.action = action
        self.path_cost = path_cost  # g(n): Chi phí đi thực tế
        self.h_cost = self.tinh_heuristic_manhattan()  # h(n): Heuristic theo khoảng cách
        self.f_cost = self.path_cost + self.h_cost  # f(n) = g(n) + h(n)

     #Khoảng cách Manhattan tới tất cả các ô bụi
    def tinh_heuristic_manhattan(self):
        # Tìm vị trí hiện tại của robot
        r_robot, c_robot = 0, 0
        for r in range(3):
            for c in range(3):
                if self.board[r][c] == "X":
                    r_robot, c_robot = r, c
                    break
        
        # Tính tổng khoảng cách từ robot tới tất cả các ô còn bụi "1"
        tong_khoang_cach = 0
        for r in range(3):
            for c in range(3):
                if self.board[r][c] == "1":
                    # Khoảng cách Manhattan: |x1 - x2| + |y1 - y2|
                    tong_khoang_cach += abs(r_robot - r) + abs(c_robot - c)
                    
        return tong_khoang_cach

    def __lt__(self, other):
        if self.f_cost == other.f_cost:
            return self.path_cost > other.path_cost
        return self.f_cost < other.f_cost

def tim_vi_tri_robot(board):
    for r in range(3):
        for c in range(3):
            if board[r][c] == "X": return r, c
    return 0, 0

def kiem_tra_dich(board):
    for r in range(3):
        for c in range(3):
            if board[r][c] == "1": return False
    return True

def sinh_node_con_astar(node):
    cac_con = []
    r, c = tim_vi_tri_robot(node.board)
    huong_di = [('LEFT', 0, -1), ('RIGHT', 0, 1), ('DOWN', 1, 0), ('UP', -1, 0)]
    
    for hanh_dong, dr, dc in huong_di:
        new_r, new_c = r + dr, c + dc
        if 0 <= new_r < 3 and 0 <= new_c < 3:
            o_sap_di = node.board[new_r][new_c]
            
            try:
                gia_tri_so = int(o_sap_di)
            except ValueError:
                gia_tri_so = 0
                
            board_moi = copy.deepcopy(node.board)
            board_moi[r][c] = "0"
            board_moi[new_r][new_c] = "X"
            
            chi_phi_g_moi = node.path_cost + gia_tri_so
            cac_con.append(NodeAStar(board_moi, node, hanh_dong, chi_phi_g_moi))
    return cac_con

def in_board_gon(board):
    r, c = tim_vi_tri_robot(board)
    so_rac = sum(row.count("1") for row in board)
    return f"Robot ở ({r},{c}) | Còn {so_rac} ô bụi"

def astar_approach():
    actions = []
    all_logs = []
    
    all_logs.append(f"=====================================")
    all_logs.append(f"  A* CÁCH 1 (H(n) k/c manhattan + G(n) số dãy ngược)")
    all_logs.append(f"=====================================")
    
    goc = NodeAStar(START_BOARD)
    all_logs.append(f"  Trạng thái gốc: {in_board_gon(goc.board)}")
    
    frontier = []
    stt_chen = 0
    heapq.heappush(frontier, (goc.f_cost, stt_chen, goc))
    
    # Tập đóng reached lưu trữ dictionary
    reached = {}
    
    while len(frontier) > 0:
        current_f, _, node = heapq.heappop(frontier)
        
        board_tuple = tuple(tuple(row) for row in node.board)
        
        if board_tuple in reached and reached[board_tuple] <= node.path_cost:
            continue
            
        reached[board_tuple] = node.path_cost
        
        if kiem_tra_dich(node.board):
            all_logs.append(f"  ==> Đã dọn SẠCH BỤI!")
            
            curr = node
            while curr.parent is not None:
                actions.append(curr.action)
                curr = curr.parent
            actions.reverse()
            
            all_logs.append(f"\n >> THÀNH CÔNG: Đã tìm thấy đường đi!")
            all_logs.append(f" >> TỔNG CHI PHÍ THẤP NHẤT: {node.path_cost}")
            return actions, all_logs
            
        cac_con = sinh_node_con_astar(node)
        for con in cac_con:
            con_tuple = tuple(tuple(row) for row in con.board)
            
            # điều kiện duyệt con dựa trên g(n) rẻ hơn tương ứng
            if con_tuple not in reached or con.path_cost < reached[con_tuple]:
                trung_va_dat_hon = False
                for f_c, _, f_node in frontier:
                    if con.board == f_node.board and con.f_cost >= f_c:
                        trung_va_dat_hon = True
                        break
                
                if not trung_va_dat_hon:
                    stt_chen += 1
                    heapq.heappush(frontier, (con.f_cost, stt_chen, con))
                    
                   
                    all_logs.append(f"  [f={con.f_cost}, g={con.path_cost}, h={con.h_cost}] A* đi xuống hướng {con.action} -> {in_board_gon(con.board)}")
                    
    all_logs.append(f" >> THẤT BẠI: Không tìm thấy đường đi sạch bụi.\n")
    return actions, all_logs