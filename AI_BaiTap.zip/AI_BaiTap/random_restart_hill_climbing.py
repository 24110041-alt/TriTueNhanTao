import random

# Hàm tính Heuristic h(n): Số ô còn bụi trên bản đồ
def tinh_heuristic(board):
    count = 0
    for i in range(3):
        for j in range(3):
            if board[i][j] == "1":
                count += 1
    return count

# Tìm tọa độ (dòng, cột) của Robot 'X'
def tim_robot(board):
    for i in range(3):
        for j in range(3):
            if board[i][j] == "X":
                return i, j

# Sinh toàn bộ các trạng thái lân cận hợp lệ (LEFT, RIGHT, UP, DOWN)
def lay_trang_thai_ke_tiep(board):
    moves = []
    r, c = tim_robot(board)
    directions = [(0, -1, "LEFT"), (0, 1, "RIGHT"), (-1, 0, "UP"), (1, 0, "DOWN")]
    
    for dr, dc, action in directions:
        nr, nc = r + dr, c + dc
        if 0 <= nr < 3 and 0 <= nc < 3:
            new_board = [row[:] for row in board]
            new_board[r][c] = "0"
            new_board[nr][nc] = "X"
            moves.append((new_board, action))
    return moves

# Kiểm tra xem bản đồ đã sạch bụi hoàn toàn chưa
def kiem_tra_sach_bui(board):
    for i in range(3):
        for j in range(3):
            if board[i][j] == "1":
                return False
    return True

# Hàm tạo một trạng thái khởi tạo ngẫu nhiên vị trí Robot trên bản đồ gốc
def khoi_tao_trang_thai_ngau_nhien():
    # Bản đồ gốc giữ nguyên các vị trí có bụi
    base_board = [
        ["0", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    # Chọn ngẫu nhiên một ô ngẫu nhiên cho Robot đứng (0 đến 2)
    r = random.randint(0, 2)
    c = random.randint(0, 2)
    
    # Đặt Robot vào vị trí ngẫu nhiên này (Nếu ô đó có bụi thì xem như hút luôn)
    base_board[r][c] = "X"
    return base_board

# Hàm chạy thuật toán Random Restart Hill Climbing 
def random_restart_hill_climbing_approach():
    # 1. Khởi tạo số lần chạy lại tối đa
    MAX_RESTART = 5
    actions = []
    logs = []
    
    logs.append("--- BẮT ĐẦU GIẢI BẰNG RANDOM RESTART HILL CLIMBING ---")
    
    # 2. CHO i = 1 đến MAX_RESTART
    for lượt in range(1, MAX_RESTART + 1):
        logs.append(f"\n=== LƯỢT CHẠY THỨ {lượt} ===")
        
        # Nếu là lượt đầu tiên thì chạy từ ma trận gốc mặc định, các lượt sau khởi tạo ngẫu nhiên
        if lượt == 1:
            current_board = [
                ["X", "1", "1"],
                ["0", "1", "0"],
                ["0", "0", "0"]
            ]
        else:
            current_board = khoi_tao_trang_thai_ngau_nhien()
            r_x, r_y = tim_robot(current_board)
            logs.append(f"Khởi tạo ngẫu nhiên vị trí mới của Robot tại: ({r_x}, {r_y})")
            
        actions_trong_luot = []
        thành_công_lượt_này = False
        
        # TƯƠNG ĐƯƠNG VÒNG LẶP TRONG KHI (đúng)
        while True:
            h_current = tinh_heuristic(current_board)
            
            # NẾU Current_State == Goal -> TRẢ VỀ Current_State
            if kiem_tra_sach_bui(current_board):
                logs.append("==> Đã dọn SẠCH BỤI hoàn toàn!")
                logs.append(f">> THÀNH CÔNG TẠI LƯỢT THỨ {lượt}!")
                thành_công_lượt_này = True
                break
                
            neighbors = lay_trang_thai_ke_tiep(current_board)
            better_neighbors = []
            
            # Lọc ra tập Better_Neighbors (Số bụi ít hơn hiện tại)
            for next_board, action in neighbors:
                h_next = tinh_heuristic(next_board)
                if h_next < h_current:
                    better_neighbors.append((next_board, action, h_next))
            
            # NẾU Better_Neighbors RÔNG:
            if not better_neighbors:
                logs.append(f"Lượt {lượt} bị kẹt ở cực đại cục bộ (Còn {h_current} ô bụi) -> Nhảy sang lượt tiếp theo")
                break # Thoát vòng lặp TRONG KHI để thực hiện Restart ở lượt i tiếp theo
                
            # NGƯỢC LẠI: Chọn trạng thái tốt nhất từ tập Better_Neighbors
            # Sắp xếp để tìm trạng thái có số bụi ít nhất (tốt nhất)
            better_neighbors.sort(key=lambda x: x[2])
            best_neighbor, best_action, _ = better_neighbors[0]
            
            current_board = best_neighbor
            actions_trong_luot.append(best_action)
            logs.append(f" Bước tiếp theo: {best_action} (Còn {tinh_heuristic(current_board)} ô bụi)")
            
        if thành_công_lượt_này:
            actions = actions_trong_luot
            return actions, logs, current_board
            
    # 3. TRẢ VỀ "Thất bại" nếu chạy hết số lượt mà không đạt Goal
    logs.append(f"\n>> THẤT BẠI: Đã chạy hết sạch {MAX_RESTART} lượt restart mà không chạm được Goal!")
    return [], logs, None