from collections import deque

# ==================================================
# INITIAL BOARD
# ==================================================
initial_board = [
    ["X", "1", "1"],
    ["0", "1", "0"],
    ["0", "0", "0"]
]

# ==================================================
# FIND ROBOT
# ==================================================
def find_robot(board):
    for i in range(3):
        for j in range(3):
            if board[i][j] == "X":
                return i, j

# ==================================================
# CHECK GOAL
# ==================================================
def is_goal(board):
    for row in board:
        if "1" in row:
            return False
    return True

# ==================================================
# CONVERT BOARD TO TUPLE
# ==================================================
def board_to_tuple(board):
    return tuple(tuple(row) for row in board)

# ==================================================
# BFS APPROACH 2 (OPTIMIZED & LOG FIXED)
# ==================================================
def bfs_approach_2():
    # Frontier lưu: (ma_trận_hiện_tại, danh_sách_hành_động)
    frontier = deque()
    frontier.append((initial_board, []))

    reached = set()
    reached.add(board_to_tuple(initial_board))
    
    logs = []

    while frontier:
        current_board, actions = frontier.popleft()
        robot = find_robot(current_board)

        # ==========================================
        # LOG CURRENT NODE
        # ==========================================
        logs.append("==============================")
        logs.append(f"Current Node: {robot}")

        # ==========================================
        # DIRECTIONS (Thứ tự chuẩn: UP → DOWN → LEFT → RIGHT)
        # ==========================================
        directions = [
            (-1, 0, "UP"),
            (1, 0, "DOWN"),
            (0, -1, "LEFT"),
            (0, 1, "RIGHT")
        ]

        x, y = robot

        for dx, dy, action in directions:
            nx = x + dx
            ny = y + dy

            # Kiểm tra kịch tường biên ma trận
            if 0 <= nx < 3 and 0 <= ny < 3:
                # Tạo nhanh ma trận con bằng list comprehension 
                child_board = [row[:] for row in current_board]
                
                # Cập nhật dịch chuyển vị trí Robot trên ma trận con
                child_board[x][y] = "0"
                
                # Kiểm tra vết bẩn để ghi nhận log dọn dẹp
                is_dust = (child_board[nx][ny] == "1")
                if is_dust:
                    child_board[nx][ny] = "0"
                
                child_board[nx][ny] = "X"
                
                child_tuple = board_to_tuple(child_board)

                # ======================================
                # KIỂM TRA TRÙNG TRẠNG THÁI (REACHED)
                # ======================================
                if child_tuple not in reached:
                    reached.add(child_tuple)
                    child_robot = (nx, ny)

                    # Ghi nhận hành vi sinh nhánh con trực quan
                    logs.append(f"Generate {action} -> {child_robot}")
                    if is_dust:
                        logs.append(f"Clean Dust at {child_robot}")

                    # Thêm vào hàng đợi thực tế
                    frontier.append((child_board, actions + [action]))

                    # Lấy danh sách toàn bộ các tọa độ Robot đang nằm chờ trong Frontier để hiển thị ra màn hình
                    current_frontier_positions = [find_robot(node[0]) for node in frontier]
                    logs.append(f"Frontier Add: {current_frontier_positions}")

                    # ==================================
                    # KIỂM TRA ĐÍCH (Đạt chuẩn Approach 2)
                    # ==================================
                    if is_goal(child_board):
                        logs.append("Goal Reached!")
                        return actions + [action], logs

    return [], ["No Solution"]