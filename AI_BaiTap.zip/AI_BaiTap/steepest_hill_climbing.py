# Hàm tính Heuristic: Sử dụng cơ chế điểm (9 - số ô bụi) 
def tinh_heuristic(board):
    count = 0
    for i in range(3):
        for j in range(3):
            if board[i][j] == "1":
                count += 1
    return 9 - count

# Tìm tọa độ (dòng, cột) của Robot 'X'
def tim_robot(board):
    for i in range(3):
        for j in range(3):
            if board[i][j] == "X":
                return i, j

# Sinh toàn bộ các trạng thái lân cận hợp lệ (LEFT, RIGHT, UP, DOWN)
def lay_trang_thai_ke_tiep(board):
    moves = []
    r, c = tim_robot(board)
    directions = [(0, -1, "LEFT"), (0, 1, "RIGHT"), (-1, 0, "UP"), (1, 0, "DOWN")]
    
    for dr, dc, action in directions:
        nr, nc = r + dr, c + dc
        if 0 <= nr < 3 and 0 <= nc < 3:
            new_board = [row[:] for row in board]
            new_board[r][c] = "0"   # Ô cũ thành ô sạch
            new_board[nr][nc] = "X"  # Ô mới có robot
            moves.append((new_board, action))
    return moves

# Kiểm tra trạng thái đích (Goal): Hết sạch bụi tức là điểm tối đa = 9
def kiem_tra_sach_bui(board):
    return tinh_heuristic(board) == 9

# Hàm chạy thuật toán Steepest Ascent Hill Climbing 
def steepest_hill_climbing_approach():
    # 1. Khởi tạo Current_State = Start
    current_board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    actions = []
    logs = []
    
    logs.append("--- BẮT ĐẦU GIẢI BẰNG STEEPEST ASCENT HILL CLIMBING ---")
    
    # 2. TRONG KHI (đúng)
    while True:
        val_current = tinh_heuristic(current_board)
        logs.append(f"Trạng thái hiện tại: Điểm đánh giá = {val_current} (Còn {9 - val_current} ô bụi)")
        
        # Nếu Current_State == Goal -> TRẢ VỀ Current_State
        if kiem_tra_sach_bui(current_board):
            logs.append("==> Đã dọn SẠCH BỤI hoàn toàn!")
            logs.append(">> THÀNH CÔNG STEEPEST ASCENT!")
            break
            
        # Sinh TẤT CẢ các trạng thái lân cận của Current_State
        neighbors = lay_trang_thai_ke_tiep(current_board)
        
        best_neighbor = None
        best_val = -1
        best_action = None
        
        # Vòng lặp quét HẾT để chọn ra trạng thái lân cận tốt nhất (Best_Neighbor)
        for next_board, action in neighbors:
            val_next = tinh_heuristic(next_board)
            r_x, r_y = tim_robot(next_board)
            logs.append(f" Xem hướng {action} -> Robot ở ({r_x},{r_y}) | Điểm đạt được: {val_next}")
            
            # Cập nhật để giữ lại phương án có điểm cao nhất trong các phương án xung quanh
            if val_next > best_val:
                best_val = val_next
                best_neighbor = next_board
                best_action = action
                
        # NẾU Value(Best_Neighbor) > Value(Current_State)
        if best_neighbor is not None and best_val > val_current:
            current_board = best_neighbor
            actions.append(best_action)
            logs.append(f">> Quyết định chọn hướng DỐC NHẤT (tốt nhất): {best_action} (Điểm: {best_val})")
            # Quay lại đầu vòng lặp với trạng thái mới
        else:
            # NGƯỢC LẠI: TRẢ VỀ Current_State (Dừng vì đạt cực đại cục bộ)
            logs.append(">> Dừng thuật toán: Các hướng xung quanh đều bằng hoặc tệ hơn hiện tại!")
            break
            
    return actions, logs