import random

# Hàm tính Heuristic h(n): Số ô còn bụi trên bản đồ
def tinh_heuristic(board):
    count = 0
    for i in range(3):
        for j in range(3):
            if board[i][j] == "1":
                count += 1
    return count

# Tìm vị trí dòng và cột hiện tại của Robot 'X'
def tim_robot(board):
    for i in range(3):
        for j in range(3):
            if board[i][j] == "X":
                return i, j

# Sinh các trạng thái kế tiếp khi Robot di chuyển (UP, DOWN, LEFT, RIGHT)
def lay_trang_thai_ke_tiep(board):
    moves = []
    r, c = tim_robot(board)
    directions = [(-1, 0, "UP"), (1, 0, "DOWN"), (0, -1, "LEFT"), (0, 1, "RIGHT")]
    
    for dr, dc, action in directions:
        nr, nc = r + dr, c + dc
        if 0 <= nr < 3 and 0 <= nc < 3:
            new_board = [row[:] for row in board]
            new_board[r][c] = "0"  # Robot đi khỏi thì ô cũ thành ô sạch
            new_board[nr][nc] = "X" # Robot đè lên ô mới (nếu có bụi thì hút luôn)
            moves.append((new_board, action))
    return moves

# Kiểm tra xem bản đồ đã sạch bụi hoàn toàn chưa (Trạng thái đích)
def kiem_tra_sach_bui(board):
    for i in range(3):
        for j in range(3):
            if board[i][j] == "1":
                return False
    return True

# Hàm tìm kiếm đệ quy có giới hạn ngưỡng (Bản chất DFS của IDA*)
def search(path, g, threshold, actions, logs):
    current_node = path[-1]
    h = tinh_heuristic(current_node)
    f = g + h
    
    # Nếu f vượt quá ngưỡng hiện tại -> Cắt tỉa (Pruning), trả về f để cập nhật ngưỡng sau
    if f > threshold:
        return f
        
    if kiem_tra_sach_bui(current_node):
        logs.append("==> Đã dọn SẠCH BỤI hoàn toàn!")
        return "FOUND"
        
    min_val = float('inf')
    
    # Duyệt qua các hướng đi kế tiếp theo cơ chế Stack (Vào sau xét trước)
    for next_board, action in lay_trang_thai_ke_tiep(current_node):
        if next_board not in path: # Tránh chu trình lặp vô hạn
            path.append(next_board)
            actions.append(action)
            
            con_lai = tinh_heuristic(next_board)
            r_x, r_y = tim_robot(next_board)
            logs.append(f"[f={g + 1 + con_lai}] IDA* mở hướng {action} -> Robot ở ({r_x},{r_y}) | Còn {con_lai} ô bụi")
            
            res = search(path, g + 1, threshold, actions, logs)
            
            if res == "FOUND":
                return "FOUND"
            if res < min_val:
                min_val = res
                
            path.pop()  # Quay lui (Backtrack) - Xóa khỏi đường đi nhánh hiện tại
            actions.pop()
            
    return min_val

# Hàm chính để file main.py gọi sang
def idastar_approach():
    # Trạng thái ma trận bụi ban đầu 
    start_board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    
    actions = []
    logs = []
    
    logs.append("--- BẮT ĐẦU GIẢI MÁY HÚT BỤI BẰNG IDA* ---")
    
    h_start = tinh_heuristic(start_board)
    logs.append(f"1) | Còn {h_start} ô bụi ban đầu")
    
    # ĐIỀU KIỆN ĐỀ BÀI: I0 = f(s) + alpha_0 (với alpha_0 lấy random từ 1 đến 2)
    alpha_0 = random.randint(1, 2)
    threshold = h_start + alpha_0
    
    logs.append(f"Khởi tạo ngưỡng ban đầu: I0 = f(s) + alpha_0 = {h_start} + {alpha_0} = {threshold}")
    
    path = [start_board]
    
    # Vòng lặp tăng dần ngưỡng (Iterative Deepening)
    while True:
        logs.append(f"Chạy tìm kiếm với Ngưỡng hiện tại (Threshold) = {threshold}")
        res = search(path, 0, threshold, actions, logs)
        
        if res == "FOUND":
            logs.append(">> THÀNH CÔNG IDA*!")
            logs.append(f">> TỔNG CHI PHÍ THỰC TẾ: {len(actions)}")
            return actions, logs
            
        if res == float('inf'):
            logs.append(">> Không tìm thấy đường đi sạch bụi!")
            return [], logs
            
        # Cập nhật ngưỡng mới bằng giá trị f nhỏ nhất đã vượt ngưỡng cũ
        threshold = res