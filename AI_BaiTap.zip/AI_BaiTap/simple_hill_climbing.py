# Hàm tính Heuristic: Đếm số ô còn bụi trên ma trận
def tinh_heuristic(board):
    count = 0
    for i in range(3):
        for j in range(3):
            if board[i][j] == "1":
                count += 1
    return count

# Tìm tọa độ (dòng, cột) hiện tại của Robot 'X'
def tim_robot(board):
    for i in range(3):
        for j in range(3):
            if board[i][j] == "X":
                return i, j

# Sinh các trạng thái kế tiếp theo thứ tự ưu tiên trên bảng: LEFT -> RIGHT -> UP -> DOWN
def lay_trang_thai_ke_tiep(board):
    moves = []
    r, c = tim_robot(board)
    directions = [(0, -1, "LEFT"), (0, 1, "RIGHT"), (-1, 0, "UP"), (1, 0, "DOWN")]
    
    for dr, dc, action in directions:
        nr, nc = r + dr, c + dc
        if 0 <= nr < 3 and 0 <= nc < 3:
            new_board = [row[:] for row in board]
            new_board[r][c] = "0"  # Vị trí cũ sạch bụi
            new_board[nr][nc] = "X" # Vị trí mới có Robot (hút bụi nếu có)
            moves.append((new_board, action))
    return moves

# Kiểm tra điều kiện dừng: Toàn bộ bản đồ đã sạch bụi chưa
def kiem_tra_sach_bui(board):
    for i in range(3):
        for j in range(3):
            if board[i][j] == "1":
                return False
    return True

# Hàm chạy thuật toán Simple Hill Climbing
def simple_hill_climbing_approach():
    # Khởi tạo trạng thái ban đầu (Current_State = Start)
    current_board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    actions = []
    logs = []
    
    logs.append("--- BẮT ĐẦU GIẢI BẰNG SIMPLE HILL CLIMBING ---")
    
    while True:
        h_current = tinh_heuristic(current_board)
        logs.append(f"Trạng thái hiện tại: Còn {h_current} ô bụi")
        
        # Nếu Current_State == Goal -> Trả về và dừng thuật toán
        if kiem_tra_sach_bui(current_board):
            logs.append("==> Đã dọn SẠCH BỤI hoàn toàn!")
            logs.append(">> THÀNH CÔNG SIMPLE HILL CLIMBING!")
            break
            
        neighbors = lay_trang_thai_ke_tiep(current_board)
        found_better = False
        
        # Duyệt qua từng trạng thái lân cận của Current_State
        for next_board, action in neighbors:
            h_next = tinh_heuristic(next_board)
            r_x, r_y = tim_robot(next_board)
            logs.append(f" Thử hướng {action} -> Robot ở ({r_x},{r_y}) | Còn {h_next} ô bụi")
            
            # Chọn ngay trạng thái ĐẦU TIÊN tốt hơn trạng thái hiện tại (Ít bụi hơn tức là tốt hơn)
            if h_next < h_current:
                current_board = next_board
                actions.append(action)
                logs.append(f">> Chọn ngay hướng đầu tiên tốt hơn: {action}")
                found_better = True
                break # Ngắt vòng lặp duyệt lân cận, quay lại bước 2
                
        # Nếu duyệt hết lân cận mà không tìm thấy ai tốt hơn -> Dừng vì đạt cực đại cục bộ
        if not found_better:
            logs.append(">> Dừng thuật toán: Bị kẹt ở cực đại cục bộ!")
            break
            
    return actions, logs