import copy

START_BOARD = [
    ["X", "1", "1"],
    ["0", "1", "0"],
    ["0", "0", "0"]
]

class NodeIDDFS:
    def __init__(self, board, parent=None, action=None, depth=0):
        self.board = board
        self.parent = parent
        self.action = action
        self.depth = depth

def tim_vi_tri_robot(board):
    for r in range(3):
        for c in range(3):
            if board[r][c] == "X": return r, c
    return 0, 0

def kiem_tra_dich(board):
    for r in range(3):
        for c in range(3):
            if board[r][c] == "1": return False
    return True

def bi_lap_vong(node):
    cha = node.parent
    while cha:
        if cha.board == node.board: return True
        cha = cha.parent
    return False

def sinh_node_con(node):
    cac_con = []
    r, c = tim_vi_tri_robot(node.board)
    huong_di = [('LEFT', 0, -1), ('RIGHT', 0, 1), ('DOWN', 1, 0), ('UP', -1, 0)]
    
    for hanh_dong, dr, dc in huong_di:
        new_r, new_c = r + dr, c + dc
        if 0 <= new_r < 3 and 0 <= new_c < 3:
            board_moi = copy.deepcopy(node.board)
            board_moi[r][c] = "0"
            board_moi[new_r][new_c] = "X"
            cac_con.append(NodeIDDFS(board_moi, node, hanh_dong, node.depth + 1))
    return cac_con

def in_board_gon(board):
    r, c = tim_vi_tri_robot(board)
    so_rac = sum(row.count("1") for row in board)
    return f"Robot({r},{c}) | Còn {so_rac} bụi"

# Hàm Tìm kiếm sâu giới hạn (DLS) đệ quy
def recursive_dls(node, limit, logs):
    if kiem_tra_dich(node.board):
        logs.append(f" -> SẠCH BỤI ở tầng {node.depth}!")
        return node
    if node.depth >= limit:
        logs.append(f" [{node.depth}] Dừng: chạm giới hạn L={limit}")
        return "cutoff"
    
    cac_con = sinh_node_con(node)
    co_cutoff = False
    
    for con in cac_con:
        if bi_lap_vong(con):
            logs.append(f" [{con.depth}] Thử {con.action} -> Lặp (Bỏ)")
            continue
        
        # Log siêu ngắn gọn giúp không bị rớt dòng
        logs.append(f" [{con.depth}] Đi {con.action} -> {in_board_gon(con.board)}")
        
        ket_qua = recursive_dls(con, limit, logs)
        if ket_qua == "cutoff":
            co_cutoff = True
        elif ket_qua is not None:
            return ket_qua
            
    return "cutoff" if co_cutoff else None

# TÊN HÀM CHÍNH ĐỂ MAIN IMPORT
def iddfs_approach_1():
    actions = []
    all_logs = []
    
    for l in range(6):
        # Thu ngắn đường kẻ để vừa vặn khung Activity
        all_logs.append(f"--- KIỂM TRA TẦNG L = {l} ---")
        
        goc = NodeIDDFS(START_BOARD)
        all_logs.append(f" Gốc: {in_board_gon(goc.board)}")
        
        logs_tang_nay = []
        kq = recursive_dls(goc, l, logs_tang_nay)
        all_logs.extend(logs_tang_nay)
        
        if kq != "cutoff" and kq is not None:
            curr = kq
            while curr.parent is not None:
                actions.append(curr.action)
                curr = curr.parent
            actions.reverse()
            all_logs.append(f"\n OK: Tìm thấy đường ở L = {l}!")
            break
        else:
            all_logs.append(f" -> L = {l} không đủ sâu.\n")
            
    return actions, all_logs