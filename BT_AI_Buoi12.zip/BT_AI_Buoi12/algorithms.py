import time
import copy

# CÁC HÀM HỖ TRỢ (TIỆN ÍCH GUI)
def delay_update(update_gui_func, phuong, mau, text):
    """
    Hàm hỗ trợ cập nhật giao diện đồ họa (GUI) kèm thời gian trễ.
    Mục đích: Giúp trực quan hóa từng bước thực thi của thuật toán.
    """
    update_gui_func(phuong, mau, text)
    time.sleep(0.8)

def kiem_tra_rang_buoc(phuong, mau_thu, assignment, ke_nhau):
    """
    Kiểm tra tính hợp lệ của giá trị (màu sắc) được gán.
    Ràng buộc: Hai vùng kề nhau không được có cùng một màu.
    """
    for hang_xom in ke_nhau[phuong]:
        if hang_xom in assignment and assignment[hang_xom] == mau_thu:
            return False # Vi phạm ràng buộc
    return True # Thỏa mãn ràng buộc

# 1. THUẬT TOÁN BACKTRACKING (TÌM KIẾM QUAY LUI)
def run_backtracking(danh_sach_phuong, mau_sac, ten_mau, ke_nhau, assignment, update_gui):
    # Bước 1: Kiểm tra điều kiện dừng. 
    # Nếu tất cả các biến đã được gán giá trị, trả về tập Assignment.
    if len(assignment) == len(danh_sach_phuong):
        return assignment
    
    # Bước 2: Chọn biến tiếp theo chưa được gán giá trị
    phuong_chua_to = [p for p in danh_sach_phuong if p not in assignment]
    phuong_hien_tai = phuong_chua_to[0] 
    
    # Bước 3: Duyệt qua miền giá trị (Domain) của biến
    for mau in mau_sac:
        delay_update(update_gui, phuong_hien_tai, mau, f"Thử gán {ten_mau[mau]} cho {phuong_hien_tai}...")
        
        # Kiểm tra ràng buộc cho phép gán hiện tại
        if kiem_tra_rang_buoc(phuong_hien_tai, mau, assignment, ke_nhau):
            # Nếu hợp lệ, tiến hành gán giá trị
            assignment[phuong_hien_tai] = mau
            delay_update(update_gui, phuong_hien_tai, mau, f"Hợp lệ: Gán {ten_mau[mau]} cho {phuong_hien_tai}.")
            
            # Gọi đệ quy để tiếp tục quá trình tìm kiếm với Assignment mới
            ket_qua = run_backtracking(danh_sach_phuong, mau_sac, ten_mau, ke_nhau, assignment, update_gui)
            if ket_qua is not None:
                return ket_qua # Tìm thấy giải pháp
            
            # Nếu không tìm thấy giải pháp, thực hiện QUAY LUI (Backtrack)
            # Xóa phép gán vừa thực hiện để thử giá trị khác
            del assignment[phuong_hien_tai]
            delay_update(update_gui, phuong_hien_tai, 'white', f"Backtrack: Xóa màu của {phuong_hien_tai} do nhánh đi vào bế tắc.")
        else:
            # Phép gán vi phạm ràng buộc
            delay_update(update_gui, phuong_hien_tai, 'white', f"Vi phạm ràng buộc: {ten_mau[mau]} bị trùng. Thử màu khác...")
            
    # Trả về None nếu duyệt hết Domain mà không có giá trị nào thỏa mãn
    return None

# 2. THUẬT TOÁN FORWARD CHECKING (KIỂM TRA TIẾN)
def run_forward_checking(danh_sach_phuong, mau_sac, ten_mau, ke_nhau, assignment, domains, update_gui):
    # Bước 1: Kiểm tra điều kiện dừng
    if len(assignment) == len(danh_sach_phuong):
        return assignment
    
    # Bước 2: Chọn biến tiếp theo chưa được gán giá trị
    phuong_chua_to = [p for p in danh_sach_phuong if p not in assignment]
    phuong_hien_tai = phuong_chua_to[0]
    
    # Bước 3: Thử các giá trị còn lại trong Domain của biến hiện tại
    for mau in domains[phuong_hien_tai]:
        delay_update(update_gui, phuong_hien_tai, mau, f"Thử {ten_mau[mau]} cho {phuong_hien_tai} (Forward Checking)")
        
        # Gán thử giá trị
        assignment[phuong_hien_tai] = mau
        
        # Khởi tạo bản sao của cấu trúc Domains để phục vụ cho thao tác Quay lui nếu cần
        new_domains = copy.deepcopy(domains)
        hop_le = True
        hang_xom_bi_loi = ""
        
        # Quá trình Forward Checking: Cập nhật lại Domain của các biến chưa được gán
        for hang_xom in ke_nhau[phuong_hien_tai]:
            if hang_xom not in assignment: # Chỉ xét các vùng kề chưa có màu
                # Loại bỏ màu vừa gán khỏi Domain của vùng kề
                if mau in new_domains[hang_xom]:
                    new_domains[hang_xom].remove(mau)
                
                # Phát hiện sớm bế tắc: Nếu Domain của bất kỳ vùng kề nào bị rỗng
                if len(new_domains[hang_xom]) == 0:
                    hop_le = False 
                    hang_xom_bi_loi = hang_xom
                    break 
        
        if hop_le:
            delay_update(update_gui, phuong_hien_tai, mau, f"Hợp lệ: Đã cập nhật Domain của các vùng kề.")
            
            # Tiếp tục đệ quy với tập Domains đã được rút gọn
            ket_qua = run_forward_checking(danh_sach_phuong, mau_sac, ten_mau, ke_nhau, assignment, new_domains, update_gui)
            if ket_qua is not None:
                return ket_qua
            
            # Backtrack: Phục hồi lại trạng thái
            del assignment[phuong_hien_tai]
            delay_update(update_gui, phuong_hien_tai, 'white', f"Backtrack: Quay lui tại {phuong_hien_tai}.")
        else:
            # Rút lại giá trị vừa gán do phát hiện lỗi sớm (Domain rỗng)
            del assignment[phuong_hien_tai] 
            delay_update(update_gui, phuong_hien_tai, 'white', f"Forward Checking: {hang_xom_bi_loi} cạn Domain! Bỏ màu {ten_mau[mau]}.")
            
    # Trả về None nếu không tìm được giải pháp
    return None