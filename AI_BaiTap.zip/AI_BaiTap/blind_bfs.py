from collections import deque

# Thuật toán chính: Tìm kiếm mù (Blind BFS)
def solve_blind_bfs(init_dirty_list):
    # 1. Tạo 9 vị trí giả định ban đầu mà Robot có thể đang đứng
    tat_ca_toado = [(r, c) for r in range(3) for c in range(3)]
    
    trang_thai_dau = []
    for toad_rb in tat_ca_toado:
        o_ban_tam = set(init_dirty_list)
        if toad_rb in o_ban_tam:
            o_ban_tam.remove(toad_rb) # Nếu robot xuất phát trúng ô bẩn thì ô đó sạch luôn
        # Lưu cặp (vị trí_robot, tập_ô_bẩn). Dùng frozenset để có thể bỏ vào Set lớn
        trang_thai_dau.append((toad_rb, frozenset(o_ban_tam)))
        
    # 2. Cấu trúc một Nút (Node) dạng Dictionary 
    nut_goc = {
        'cac_trang_thai': frozenset(trang_thai_dau),
        'cha': None,
        'hanh_dong': None,
        'ten': "Nut_1"
    }
    
    hang_doi = deque([nut_goc])
    da_duyet = set()
    history_logs = []
    dem_nut = 1
    
    history_logs.append(f"[KHỞI TẠO BLIND BFS]\n-> Đã tạo nút gốc với {len(nut_goc['cac_trang_thai'])} trường hợp giả định ban đầu.\n")
    
    action_options = ["U", "D", "L", "R"]
    
    while hang_doi:
        curr = hang_doi.popleft()
        node_key = curr['cac_trang_thai']
        
        if node_key in da_duyet:
            continue
        da_duyet.add(node_key)
        
        # Tạo chuỗi log văn bản đơn giản
        msg = f"==> Đang duyệt [{curr['ten']}]\n"
        if curr['cha']:
            msg += f"- Đi từ: [{curr['cha']['ten']}] qua hướng: [{curr['hanh_dong']}]\n"
        msg += f"- Số cấu hình robot khả thi: {len(node_key)}\n"
        
        # KIỂM TRA ĐÍCH: Nếu TẤT CẢ các cấu hình giả định đều sạch bụi (len == 0) thì dừng
        is_goal = True
        for rb_pos, dirty_set in node_key:
            if len(dirty_set) > 0:
                is_goal = False
                break
                
        if is_goal:
            msg += f"[THÀNH CÔNG] Tìm thấy chuỗi giải pháp tại [{curr['ten']}]!"
            history_logs.append(msg)
            
            # Truy vết ngược từ nút đích về nút cha để lấy đường đi
            solution_path = []
            tracker = curr
            while tracker is not None:
                solution_path.append(tracker)
                tracker = tracker['cha']
            solution_path.reverse() 
            return solution_path, history_logs
            
        # 3. Duyệt 4 hướng đi để sinh nút con
        created_branches = []
        for act in action_options:
            child_states = set()
            
            for rb_pos, dirty_set in node_key:
                r, c = rb_pos
                # Di chuyển vị trí theo hướng
                if act == "U" and r > 0: r -= 1
                elif act == "D" and r < 2: r += 1
                elif act == "L" and c > 0: c -= 1
                elif act == "R" and c < 2: c += 1
                
                # Cập nhật hút bụi tại ô mới đến
                updated_dirty = set(dirty_set)
                if (r, c) in updated_dirty:
                    updated_dirty.remove((r, c))
                    
                child_states.add(( (r, c), frozenset(updated_dirty) ))
                
            khoa_con = frozenset(child_states)
            if khoa_con not in da_duyet:
                dem_nut += 1
                nut_con = {
                    'cac_trang_thai': khoa_con,
                    'cha': curr,
                    'hanh_dong': act,
                    'ten': f"Nut_{dem_nut}"
                }
                hang_doi.append(nut_con)
                created_branches.append(f"Hướng [{act}] -> Sinh ra [{nut_con['ten']}] ({len(khoa_con)} trạng thái)")
                
        if created_branches:
            msg += "Các nút con được sinh ra:\n"
            for branch in created_branches:
                msg += f"   + {branch}\n"
        history_logs.append(msg)
                
    return None, history_logs