import copy

# ==================================================
# INITIAL BOARD
# ==================================================
initial_board = [
    ["X", "1", "1"],
    ["0", "1", "0"],
    ["0", "0", "0"]
]

# ==================================================
# CHECK GOAL
# ==================================================
def is_goal(board):
    for row in board:
        if "1" in row:
            return False
    return True

# ==================================================
# DFS APPROACH 1
# ==================================================
def dfs_approach_1():
    # Đúng bản chất Approach 1: Sử dụng một bản đồ bụi duy nhất xuyên suốt
    global_board = copy.deepcopy(initial_board)

    # STACK lưu: (tọa độ_hiện_tại, danh_sách_hành_động)
    # Không truyền trạng thái board vào stack để tránh biến thành Approach 2
    stack = []
    start = (0, 0)
    stack.append((start, []))

    visited = set()
    logs = []

    while stack:
        current, actions = stack.pop()
        x, y = current

        # Nếu gặp nút đã duyệt trong nhánh khác -> Bỏ qua (Backtrack)
        if current in visited:
            logs.append("==============================")
            logs.append(f"Current Node: {current} (Already Visited) -> Backtrack")
            continue
            
        visited.add(current)

        # ==========================================
        # LOG CURRENT NODE WHEN POPPED
        # ==========================================
        logs.append("==============================")
        logs.append(f"Current Node: {current}")

        # Đồng bộ vị trí robot trên bản đồ toàn cục
        for i in range(3):
            for j in range(3):
                if global_board[i][j] == "X":
                    global_board[i][j] = "0"
        
        # ==========================================
        # HÚT BỤI TẠI CHỖ (Nếu ô hiện tại đang có bụi)
        # ==========================================
        if global_board[x][y] == "1":
            global_board[x][y] = "0"
            logs.append(f"Clean Dust at {current}")
            
        global_board[x][y] = "X"

        # ==========================================
        # KIỂM TRA ĐÍCH
        # ==========================================
        if is_goal(global_board):
            logs.append("Goal Reached!")
            return actions, logs

        # ==========================================
        # THỨ TỰ ƯU TIÊN: DOWN → RIGHT → UP → LEFT
        # Đẩy vào Stack ngược lại: LEFT, UP, RIGHT, DOWN
        # ==========================================
        directions = [
            (0, -1, "LEFT"),
            (-1, 0, "UP"),
            (0, 1, "RIGHT"),
            (1, 0, "DOWN")
        ]

        moved = False
        # Duyệt qua các hướng để tìm nhánh đi sâu tiếp theo
        for dx, dy, action in directions:
            nx = x + dx
            ny = y + dy

            if 0 <= nx < 3 and 0 <= ny < 3:
                child = (nx, ny)
                if child not in visited:
                    # Log định hướng "Go" ngay khi sinh nhánh con để tăng tính liên tục
                    logs.append(f"Go {action} -> {child}")
                    stack.append((child, actions + [action]))
                    moved = True

        # Nếu đứng ở ô này mà kịch tường hoặc xung quanh đã đi qua hết -> Ngõ cụt!
        if not moved:
            logs.append("Dead End -> Preparing to Backtrack")

    return [], logs