#H(n) số ô sai + G(n) số dãy ngược
import copy
import heapq

START_BOARD = [
    ["X", "1", "1"],
    ["0", "1", "0"],
    ["0", "0", "0"]
]

class NodeAStar3:
    def __init__(self, board, parent=None, action=None, path_cost=0, visited_tiles=None):
        self.board = board
        self.parent = parent
        self.action = action
        self.path_cost = path_cost  # Chi phí thực tế bước đi
        
        if visited_tiles is None:
            self.visited_tiles = set()
        else:
            self.visited_tiles = set(visited_tiles)
            
        r_rob, c_rob = self.tim_robot()
        self.visited_tiles.add((r_rob, c_rob))

        self.h_cost = self.tinh_so_o_bui()        
        self.q_cost = self.tinh_4_day_nguoc()      
        
        # f(n) = h(n) + g(n) + q(n)
        self.f_cost = self.h_cost + self.path_cost + self.q_cost

    def tim_robot(self):
        for r in range(3):
            for c in range(3):
                if self.board[r][c] == "X": return r, c
        return 0, 0

    def tinh_so_o_bui(self):
        return sum(row.count("1") for row in self.board)

    def tinh_4_day_nguoc(self):
        r_robot, c_robot = self.tim_robot()
        if (r_robot, c_robot) in self.visited_tiles and len(self.visited_tiles) > 1:
            return 2  # Điểm phạt đi ngược hướng
        return 0

    def __lt__(self, other):
        if self.f_cost == other.f_cost:
            return self.path_cost > other.path_cost
        return self.f_cost < other.f_cost

def tim_vi_tri_robot(board):
    for r in range(3):
        for c in range(3):
            if board[r][c] == "X": return r, c
    return 0, 0

def kiem_tra_dich(board):
    for r in range(3):
        for c in range(3):
            if board[r][c] == "1": return False
    return True

def sinh_node_con_astar(node):
    cac_con = []
    r, c = tim_vi_tri_robot(node.board)
    huong_di = [('LEFT', 0, -1), ('RIGHT', 0, 1), ('DOWN', 1, 0), ('UP', -1, 0)]
    
    for hanh_dong, dr, dc in huong_di:
        new_r, new_c = r + dr, c + dc
        if 0 <= new_r < 3 and 0 <= new_c < 3:
            o_sap_di = node.board[new_r][new_c]
            try:
                gia_tri_so = int(o_sap_di)
            except ValueError:
                gia_tri_so = 0
                
            board_moi = copy.deepcopy(node.board)
            board_moi[r][c] = "0"
            board_moi[new_r][new_c] = "X"
            
            chi_phi_g_moi = node.path_cost + gia_tri_so
            cac_con.append(NodeAStar3(board_moi, node, hanh_dong, chi_phi_g_moi, node.visited_tiles))
    return cac_con

def in_board_gon(board):
    r, c = tim_vi_tri_robot(board)
    so_rac = sum(row.count("1") for row in board)
    return f"Robot ở ({r},{c}) | Còn {so_rac} ô bụi"

def astar_2_approach():
    actions = []
    all_logs = []
    
    all_logs.append("=====================================")
    all_logs.append("  A* CÁCH 3 (H(n) số ô sai + G(n) số dãy ngược)")
    all_logs.append("=====================================")
    
    goc = NodeAStar3(START_BOARD)
    all_logs.append(f"  Trạng thái gốc: {in_board_gon(goc.board)}")
    
    frontier = []
    stt_chen = 0
    heapq.heappush(frontier, (goc.f_cost, stt_chen, goc))
    reached = {}
    
    while len(frontier) > 0:
        _, _, node = heapq.heappop(frontier)
        board_tuple = tuple(tuple(row) for row in node.board)
        
        if board_tuple in reached and reached[board_tuple] <= node.path_cost:
            continue
        reached[board_tuple] = node.path_cost
        
        if kiem_tra_dich(node.board):
            all_logs.append(f"  ==> Đã dọn SẠCH BỤI!")
            curr = node
            while curr.parent is not None:
                actions.append(curr.action)
                curr = curr.parent
            actions.reverse()
            all_logs.append(f"\n >> THÀNH CÔNG CÁCH 3!")
            all_logs.append(f" >> TỔNG CHI PHÍ THỰC TẾ: {node.path_cost}")
            return actions, all_logs
            
        for con in sinh_node_con_astar(node):
            con_tuple = tuple(tuple(row) for row in con.board)
            if con_tuple not in reached or con.path_cost < reached[con_tuple]:
                stt_chen += 1
                heapq.heappush(frontier, (con.f_cost, stt_chen, con))
                all_logs.append(f"  [f={con.f_cost}] C3 mở hướng {con.action} -> {in_board_gon(con.board)}")
                
    all_logs.append(f" >> THẤT BẠI: Không tìm thấy đường đi.\n")
    return actions, all_logs