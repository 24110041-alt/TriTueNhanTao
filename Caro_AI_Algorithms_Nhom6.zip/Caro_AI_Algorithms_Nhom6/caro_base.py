import tkinter as tk

class CaroBase:
    def __init__(self, root, title="Caro AI Project"):
        self.root = root
        self.root.title(title)
        self.board = [' ' for _ in range(9)]
        self.turn = 'X' # X đi trước
        
        # --- Giao diện (UI) ---
        main_frame = tk.Frame(root)
        main_frame.pack(padx=15, pady=15)
        
        self.board_frame = tk.Frame(main_frame)
        self.board_frame.grid(row=0, column=0)
        
        # Tạo lưới 3x3
        self.buttons = [tk.Button(self.board_frame, text='', font=('Arial', 24, 'bold'), 
                                  width=5, height=2, state=tk.DISABLED, bg='#f0f0f0') 
                        for _ in range(9)]
        for i, btn in enumerate(self.buttons):
            btn.grid(row=i//3, column=i%3, padx=2, pady=2)
            
        # Khung in log
        self.log_text = tk.Text(main_frame, width=50, height=18, font=('Consolas', 10), bg='#fafafa')
        self.log_text.grid(row=0, column=1, padx=15)
        
        self.result_label = tk.Label(root, text="Đang phân tích nước đi...", font=('Arial', 14, 'bold'), fg='#d35400')
        self.result_label.pack(pady=10)
        
        # Bắt đầu vòng lặp game sau 1 giây
        self.root.after(1000, self.play_turn)

    def log(self, message):
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)

    def check_winner(self):
        # Kiểm tra toàn bộ điều kiện thắng
        win_coords = [(0,1,2), (3,4,5), (6,7,8), (0,3,6), (1,4,7), (2,5,8), (0,4,8), (2,4,6)]
        for c in win_coords:
            if self.board[c[0]] == self.board[c[1]] == self.board[c[2]] and self.board[c[0]] != ' ': 
                return self.board[c[0]]
        return 'Tie' if ' ' not in self.board else None

    def play_turn(self):
        # Hàm này sẽ bị ghi đè (override) bởi các thuật toán AI ở class con
        pass