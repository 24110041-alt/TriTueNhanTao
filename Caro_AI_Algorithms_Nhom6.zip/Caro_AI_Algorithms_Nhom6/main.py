import tkinter as tk
import subprocess
import sys

class MainDashboard:
    def __init__(self, root):
        self.root = root
        self.root.title("Hệ thống Mô phỏng AI - Cờ Caro")
        self.root.geometry("450x350")
        self.root.configure(bg='#ecf0f1')
        
        title_lbl = tk.Label(root, text="CHỌN THUẬT TOÁN ĐỂ CHẠY", 
                             font=('Arial', 16, 'bold'), bg='#ecf0f1', fg='#2c3e50')
        title_lbl.pack(pady=(30, 20))

        # Cấu hình nút bấm
        btn_style = {'font': ('Arial', 12, 'bold'), 'width': 30, 'height': 2, 'cursor': 'hand2'}

        btn_minimax = tk.Button(root, text=" Thuật toán Minimax", bg='#3498db', fg='white',
                                command=lambda: self.run_app("minimax.py"), **btn_style)
        btn_minimax.pack(pady=10)

        btn_alphabeta = tk.Button(root, text=" Thuật toán Alpha-Beta", bg='#e67e22', fg='white',
                                  command=lambda: self.run_app("alpha_beta.py"), **btn_style)
        btn_alphabeta.pack(pady=10)

        btn_expectimax = tk.Button(root, text=" Thuật toán Expectimax", bg='#9b59b6', fg='white',
                                   command=lambda: self.run_app("expectimax.py"), **btn_style)
        btn_expectimax.pack(pady=10)

    def run_app(self, script_name):
        # Mở file Python độc lập
        subprocess.Popen([sys.executable, script_name])

if __name__ == "__main__":
    root = tk.Tk()
    app = MainDashboard(root)
    root.mainloop()