import tkinter as tk
from caro_base import CaroBase

class CaroMinimax(CaroBase):
    def __init__(self, root):
        super().__init__(root, title="Thuật toán Minimax Tối ưu")

    def minimax(self, depth, is_maximizing):
        winner = self.check_winner()
        if winner == 'X': return 10 - depth
        if winner == 'O': return depth - 10
        if winner == 'Tie': return 0

        if is_maximizing:
            best_score = -float('inf')
            for i in range(9):
                if self.board[i] == ' ':
                    self.board[i] = 'X'
                    best_score = max(best_score, self.minimax(depth + 1, False))
                    self.board[i] = ' ' # Trả lại trạng thái
            return best_score
        else:
            best_score = float('inf')
            for i in range(9):
                if self.board[i] == ' ':
                    self.board[i] = 'O'
                    best_score = min(best_score, self.minimax(depth + 1, True))
                    self.board[i] = ' '
            return best_score

    def play_turn(self):
        winner = self.check_winner()
        if winner:
            self.result_label.config(text=f"Kết thúc: {winner if winner != 'Tie' else 'Hòa!'}", fg='green')
            return

        self.log(f"--- Đến lượt {self.turn} (Minimax) ---")
        best_score = -float('inf') if self.turn == 'X' else float('inf')
        move = -1
        
        for i in range(9):
            if self.board[i] == ' ':
                self.board[i] = self.turn
                score = self.minimax(0, self.turn == 'O')
                self.board[i] = ' '
                self.log(f" * Phân tích ô {i}: Điểm kỳ vọng {score}")
                
                if self.turn == 'X' and score > best_score:
                    best_score, move = score, i
                elif self.turn == 'O' and score < best_score:
                    best_score, move = score, i
        
        self.board[move] = self.turn
        self.buttons[move].config(text=self.turn, fg='blue' if self.turn == 'X' else 'red')
        self.log(f">> Quyết định chốt ô {move} (Điểm: {best_score})\n")
        
        self.turn = 'O' if self.turn == 'X' else 'X'
        self.root.after(800, self.play_turn)

if __name__ == "__main__":
    root = tk.Tk()
    app = CaroMinimax(root)
    root.mainloop()