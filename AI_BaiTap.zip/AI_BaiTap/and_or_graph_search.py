class VacuumState:
    def __init__(self, agent_pos, dirty_cells):
        self.agent_pos = agent_pos
        self.dirty_cells = frozenset(dirty_cells)

    def __eq__(self, other):
        return self.agent_pos == other.agent_pos and self.dirty_cells == other.dirty_cells

    def __hash__(self):
        return hash((self.agent_pos, self.dirty_cells))
        
    def __str__(self):
        return f"Robot{self.agent_pos} - Còn {len(self.dirty_cells)} bụi"

    def get_action_result(self, action, rows, cols):
        r, c = self.agent_pos
        new_dirty = set(self.dirty_cells)
        if action == "U" and r > 0: r -= 1
        elif action == "D" and r < rows - 1: r += 1
        elif action == "L" and c > 0: c -= 1
        elif action == "R" and c < cols - 1: c += 1
        
        # Hút bụi
        if (r, c) in new_dirty:
            new_dirty.remove((r, c))
        return VacuumState((r, c), frozenset(new_dirty))


class Problem:
    def __init__(self, start_pos, initial_dirty, rows=3, cols=3):
        self.rows = rows
        self.cols = cols
        self.logs = []
        self.initial_state = VacuumState(start_pos, frozenset(initial_dirty))

    def goal_test(self, state):
        return len(state.dirty_cells) == 0

    def actions(self, state):
        r, c = state.agent_pos
        acts = ["U", "D", "L", "R"]
        
        # Heuristic nhỏ: Ưu tiên đi về hướng có rác để thuật toán không bị chạy vòng vòng
        def distance_to_dirt(a):
            nr, nc = r, c
            if a == "U": nr -= 1
            elif a == "D": nr += 1
            elif a == "L": nc -= 1
            elif a == "R": nc += 1
            if not state.dirty_cells: return 0
            return min(abs(nr - dr) + abs(nc - dc) for dr, dc in state.dirty_cells)
            
        acts.sort(key=distance_to_dirt)
        return acts

    def results(self, state, action):
        # Môi trường trả về 1 kịch bản trạng thái mới
        return [state.get_action_result(action, self.rows, self.cols)]


def AND_OR_GRAPH_SEARCH(problem):
    problem.logs.append("--- BẮT ĐẦU AND-OR-GRAPH SEARCH ---")
    
    # return OR_SEARCH(problem.initial_state, problem, [])
    plan = OR_SEARCH(problem.initial_state, problem, [])
    return plan, problem.logs


def OR_SEARCH(state, problem, path):
    indent = "  " * len(path) # Lùi lề theo độ sâu để log dễ nhìn
    problem.logs.append(f"{indent}[OR] Xét {state}")

    # if state in problem.goal_test: return []
    if problem.goal_test(state):
        problem.logs.append(f"{indent}  => [GOAL] Đã sạch rác! Trả về []")
        return []
        
    # if state in path: return failure // tránh lặp
    if state in path:
        problem.logs.append(f"{indent}  => [LẶP] Trạng thái lặp lại! Thất bại.")
        return "failure"

    # for each action in problem.actions(state):
    for action in problem.actions(state):
        problem.logs.append(f"{indent}  + Thử hành động: {action}")
        
        # result_states = problem.results(state, action)
        result_states = problem.results(state, action)
        
        # plan = AND_SEARCH(result_states, problem, path + [state])
        plan = AND_SEARCH(result_states, problem, path + [state])
        
        # if plan != failure: return [action, plan]
        if plan != "failure":
            problem.logs.append(f"{indent}  => [CHỐT] Chọn hướng {action} thành công.")
            return [action, plan]
            
    # return failure
    problem.logs.append(f"{indent}  => [BẾ TẮC] Không còn đường đi hợp lệ.")
    return "failure"


def AND_SEARCH(states, problem, path):
    indent = "  " * len(path)
    problem.logs.append(f"{indent}[AND] MT trả về {len(states)} kịch bản:")
    
    # plans = empty mapping
    plans = {}
    
    # for each s in states:
    for i, s in enumerate(states):
        problem.logs.append(f"{indent}  - KB {i+1}: {s}")
        
        # plan_s = OR_SEARCH(s, problem, path)
        plan_s = OR_SEARCH(s, problem, path)
        
        # if plan_s == failure: return failure
        if plan_s == "failure":
            problem.logs.append(f"{indent}  => [AND LỖI] Kịch bản {i+1} hỏng -> Hủy nhánh!")
            return "failure"
            
        # plans[s] = plan_s
        plans[s] = plan_s
        
    # return plans
    return plans