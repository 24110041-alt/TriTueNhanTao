import random

# Hàm tính Heuristic h(n): Số ô còn bụi trên bản đồ
def tinh_heuristic(board):
    count = 0
    for i in range(3):
        for j in range(3):
            if board[i][j] == "1":
                count += 1
    return count

# Tìm tọa độ (dòng, cột) của Robot 'X'
def tim_robot(board):
    for i in range(3):
        for j in range(3):
            if board[i][j] == "X":
                return i, j

# Sinh toàn bộ các trạng thái lân cận hợp lệ (LEFT, RIGHT, UP, DOWN)
def lay_trang_thai_ke_tiep(board):
    moves = []
    r, c = tim_robot(board)
    directions = [(0, -1, "LEFT"), (0, 1, "RIGHT"), (-1, 0, "UP"), (1, 0, "DOWN")]
    
    for dr, dc, action in directions:
        nr, nc = r + dr, c + dc
        if 0 <= nr < 3 and 0 <= nc < 3:
            new_board = [row[:] for row in board]
            new_board[r][c] = "0"
            new_board[nr][nc] = "X"
            moves.append((new_board, action))
    return moves

# Kiểm tra xem bản đồ đã sạch bụi hoàn toàn chưa
def kiem_tra_sach_bui(board):
    for i in range(3):
        for j in range(3):
            if board[i][j] == "1":
                return False
    return True

# Hàm chạy thuật toán Stochastic Hill Climbing 
def stochastic_hill_climbing_approach():
    # 1. Current_State = Start
    current_board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    actions = []
    logs = []
    
    logs.append("--- BẮT ĐẦU GIẢI MÁY HÚT BỤI BẰNG STOCHASTIC HILL CLIMBING ---")
    
    # 2. TRONG KHI (đúng)
    while True:
        h_current = tinh_heuristic(current_board)
        logs.append(f"Trạng thái hiện tại: Còn {h_current} ô bụi")
        
        # Nếu Current_State == Goal -> TRẢ VỀ Current_State
        if kiem_tra_sach_bui(current_board):
            logs.append("==> Đã dọn SẠCH BỤI hoàn toàn!")
            logs.append(">> THÀNH CÔNG STOCHASTIC HILL CLIMBING!")
            break
            
        # Sinh tất cả các trạng thái lân cận của Current_State
        neighbors = lay_trang_thai_ke_tiep(current_board)
        
        # Lọc ra tập Better_Neighbors (Trạng thái có số bụi ít hơn hiện tại)
        better_neighbors = []
        for next_board, action in neighbors:
            h_next = tinh_heuristic(next_board)
            if h_next < h_current:
                better_neighbors.append((next_board, action))
                logs.append(f" Phát hiện hướng tốt hơn: {action} (Còn {h_next} ô bụi)")
                
        # NẾU Better_Neighbors RỖNG -> TRẢ VỀ Current_State (Dừng vì đạt cực đại cục bộ)
        if not better_neighbors:
            logs.append(">> Dừng thuật toán: Tập Better_Neighbors rỗng (Chạm cực đại cục bộ)!")
            break
            
        # NGƯỢC LẠI: Chọn ngẫu nhiên một trạng thái từ tập Better_Neighbors
        next_board, action = random.choice(better_neighbors)
        current_board = next_board
        actions.append(action)
        
        logs.append(f">> [Ngẫu nhiên] Chọn ngẫu nhiên hướng đi tiếp: {action}")
        
    return actions, logs