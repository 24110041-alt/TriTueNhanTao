from collections import deque

# =========================================================
# HÀM BỔ TRỢ: XUẤT MA TRẬN 
# =========================================================
def get_matrix_multiline_str(dirty_cells_set, rows=3, cols=3):
    lines = []
    for r in range(rows):
        row_str = []
        for c in range(cols):
            row_str.append("1" if (r, c) in dirty_cells_set else "0")
        lines.append("      " + " ".join(row_str))
    return "\n".join(lines)

def name_generator():
    letters = [chr(i) for i in range(65, 91)] # 'A' -> 'Z'
    for letter in letters:
        yield letter
    suffix = 1
    while True:
        for letter in letters:
            yield f"{letter}{suffix}"
        suffix += 1

# =========================================================
# 1. LỚP BIỂU DIỄN TRẠNG THÁI ĐƠN LẺ (SINGLE STATE)
# =========================================================
class VacuumState:
    def __init__(self, agent_pos, dirty_cells):
        self.agent_pos = agent_pos                
        self.dirty_cells = frozenset(dirty_cells) 

    def __eq__(self, other):
        return self.agent_pos == other.agent_pos and self.dirty_cells == other.dirty_cells

    def __hash__(self):
        return hash((self.agent_pos, self.dirty_cells))

    def get_detailed_str(self):
        matrix_block = get_matrix_multiline_str(self.dirty_cells, rows=3, cols=3)
        return f"   + Robot ở vị trí {self.agent_pos}\n   + Sơ đồ ma trận ô bẩn:\n{matrix_block}"

    def get_percept(self):
        return 1 if self.agent_pos in self.dirty_cells else 0

    def transition(self, action, rows, cols):
        r, c = self.agent_pos
        new_dirty = set(self.dirty_cells)
        
        if action == "U" and r > 0: r -= 1
        elif action == "D" and r < rows - 1: r += 1
        elif action == "L" and c > 0: c -= 1
        elif action == "R" and c < cols - 1: c += 1
        
        if (r, c) in new_dirty:
            new_dirty.remove((r, c))
            
        return VacuumState((r, c), new_dirty)

# =========================================================
# 2. LỚP NÚT TẬP NIỀM TIN (BELIEF-STATE NODE)
# =========================================================
class BeliefNode:
    def __init__(self, states, parent=None, action=None, step=0, name="A", percept_trigger=None):
        self.states = frozenset(states) 
        self.parent = parent            
        self.action = action            
        self.step = step                
        self.name = name                 
        self.percept_trigger = percept_trigger 

    def get_key(self):
        return self.states

# =========================================================
# 3. THUẬT TOÁN TÌM KIẾM TRONG MÔI TRƯỜNG NHÌN THẤY MỘT PHẦN
# =========================================================
def partially_observable_bfs(rows, cols, initial_dirty):
    gen = name_generator()
    steps_log = []
    
    all_positions = [(r, c) for r in range(rows) for c in range(cols)]
    start_states = []
    for pos in all_positions:
        r, c = pos
        new_dirty = set(initial_dirty)
        if (r, c) in new_dirty:
            new_dirty.remove((r, c))
        start_states.append(VacuumState(pos, new_dirty))
        
    root_node = BeliefNode(states=start_states, parent=None, action=None, step=0, name=next(gen))
    
    frontier = deque([root_node])
    reached = set()
    actions_list = ["U", "D", "L", "R"]
    solution_nodes = [] 
    
    steps_log.append(f"[KHỞI TẠO] Tập niềm tin gốc [{root_node.name}] có {len(root_node.states)} trường hợp.")

    while frontier:
        curr_node = frontier.popleft()
        curr_key = curr_node.get_key()
        
        if curr_key in reached:
            continue
        reached.add(curr_key)
        
        # Log 1 dòng duy nhất, ngắn gọn, dễ đọc, đã đổi chữ thành Cảm biến báo
        log_line = f"Duyệt [{curr_node.name}]"
        if curr_node.parent:
            per_str = "BẨN" if curr_node.percept_trigger == 1 else "SẠCH"
            log_line += f" | Từ [{curr_node.parent.name}] đi {curr_node.action} (Cảm biến báo {per_str})"
        
        is_goal_reached = True
        for s in curr_node.states:
            if len(s.dirty_cells) > 0:
                is_goal_reached = False
                break

        if is_goal_reached:
            steps_log.append(log_line + f" => SẠCH BỤI! THÀNH CÔNG!")
            
            temp = curr_node
            while temp is not None:
                solution_nodes.append(temp)
                temp = temp.parent
            solution_nodes.reverse()
            return solution_nodes, steps_log
            
        push_log_actions = []
        for action in actions_list:
            moved_states = set()
            for state in curr_node.states:
                moved_states.add(state.transition(action, rows, cols))
                
            for percept in [0, 1]:
                filtered_states = [s for s in moved_states if s.get_percept() == percept]
                if not filtered_states:
                    continue
                    
                child_node = BeliefNode(states=filtered_states, parent=curr_node, action=action, step=curr_node.step + 1, name="", percept_trigger=percept)
                child_key = child_node.get_key()
                
                if child_key not in reached:
                    child_node.name = next(gen)
                    frontier.append(child_node) 
                    # Ký hiệu gọn: vd Hướng U, cảm biến báo 0 -> Nút C
                    push_log_actions.append(f"{action}({percept})->{child_node.name}")
                    
        if push_log_actions:
            log_line += f" | Sinh nhánh: " + ", ".join(push_log_actions)
        else:
            log_line += " | Ngõ cụt!"
            
        steps_log.append(log_line)
        
    return None, steps_log