import random
import math

def tinh_heuristic(board):
    count = 0
    for i in range(3):
        for j in range(3):
            if board[i][j] == "1":
                count += 1
    return count

def tim_robot(board):
    for i in range(3):
        for j in range(3):
            if board[i][j] == "X":
                return i, j

def lay_trang_thai_ke_tiep(board):
    moves = []
    r, c = tim_robot(board)
    directions = [(-1, 0, "UP"), (1, 0, "DOWN"), (0, -1, "LEFT"), (0, 1, "RIGHT")]
    
    for dr, dc, action in directions:
        nr, nc = r + dr, c + dc
        if 0 <= nr < 3 and 0 <= nc < 3:
            new_board = [row[:] for row in board]
            new_board[r][c] = "0"
            if new_board[nr][nc] == "1":
                new_board[nr][nc] = "0"
            new_board[nr][nc] = "X"
            moves.append((new_board, action))
    return moves

def simulated_annealing_approach():
    logs = []
    logs.append("--- KHỞI CHẠY THUẬT TOÁN SIMULATED ANNEALING ---")
    
    current_board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    
   
    T = 10.0       
    Tmin = 1.0     
    alpha = 0.92   
    
    actions = []
    buoc = 1
    is_success = False
    
    while T > Tmin:
        h_current = tinh_heuristic(current_board)
        logs.append(f"\n [CHU KỲ {buoc}] Nhiệt độ T = {T:.2f} | Hàm mục tiêu h(current) = {h_current}")
        
        if h_current == 0:
            logs.append("\n==========================================")
            logs.append("==> Đạt Trạng thái Đích (Goal State) thành công!")
            logs.append("==========================================")
            is_success = True
            break
            
        neighbors = lay_trang_thai_ke_tiep(current_board)
        if not neighbors:
            logs.append(" Không còn trạng thái lân cận hợp lệ!")
            break
            
        logs.append(" Khảo sát các trạng thái lân cận có thể dịch chuyển:")
        for nb_board, nb_action in neighbors:
            nb_h = tinh_heuristic(nb_board)
            nb_delta = nb_h - h_current
            if nb_delta < 0:
                logs.append(f"  + Hướng {nb_action}: h = {nb_h} (Delta = {nb_delta}) -> [TỐT]")
            elif nb_delta == 0:
                logs.append(f"  + Hướng {nb_action}: h = {nb_h} (Delta = {nb_delta}) -> [BẰNG NHAU]")
            else:
                logs.append(f"  + Hướng {nb_action}: h = {nb_h} (Delta = {nb_delta}) -> [TỆ HƠN]")
        
        next_board, action = random.choice(neighbors)
        h_next = tinh_heuristic(next_board)
        delta = h_next - h_current
        
        logs.append(f"Quyết định chọn ngẫu nhiên hướng [{action}] để kiểm tra điều kiện:")
        
        if delta < 0:
            current_board = next_board
            actions.append(action)
            logs.append(f"  ---> Kết quả: Delta = {delta} < 0. Chấp nhận dịch chuyển sang hướng tốt: {action}")
        else:
            try:
                p = math.exp(-delta / T)
            except OverflowError:
                p = 0.0
                
            rand_val = random.random()
            logs.append(f"  ---> Kết quả: Delta = {delta} >= 0. Tính xác suất p = {p:.4f} | Số ngẫu nhiên r = {rand_val:.4f}")
            
            if rand_val < p:
                current_board = next_board
                actions.append(action)
                logs.append(f"  ---> Chấp nhận hướng [{action}] nhờ cơ chế vượt cực trị cục bộ (r < p)!")
            else:
                logs.append(f"  ---> Bác bỏ hướng [{action}], giữ nguyên trạng thái.")
                
        T = alpha * T
        buoc += 1
        
    # Trả về thêm biến kiểm tra xem có dọn sạch bụi thật không
    return actions, logs, is_success