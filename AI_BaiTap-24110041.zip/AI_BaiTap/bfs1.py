from collections import deque
import copy

# Ma trận trạng thái ban đầu (Cố định để tính toán)
initial_board = [
    ["X", "1", "1"],
    ["0", "1", "0"],
    ["0", "0", "0"]
]

# Hàm tự tính ma trận bụi dựa trên chuỗi hành động đi kèm của node
def get_board_after_actions(actions):
    current_board = copy.deepcopy(initial_board)
    rx, ry = 0, 0
    
    # Hút bụi tại vị trí xuất phát (0, 0) nếu có
    if current_board[rx][ry] == "1":
        current_board[rx][ry] = "0"
        
    # Duyệt từng bước đi thực tế để cập nhật trạng thái bụi
    for action in actions:
        if action == "UP": rx -= 1
        elif action == "DOWN": rx += 1
        elif action == "LEFT": ry -= 1
        elif action == "RIGHT": ry += 1
        
        # Robot đi đến đâu, bụi trên bản đồ bị xóa đến đó
        if current_board[rx][ry] == "1":
            current_board[rx][ry] = "0"
            
    # Đặt vị trí Robot hiện tại vào ma trận
    current_board[rx][ry] = "X"
    return current_board

# Hàm đếm số lượng hạt bụi còn lại trên board
def count_dust(board):
    count = 0
    for row in board:
        count += row.count("1")
    return count

# Hàm tìm tọa độ hiện tại của robot (X)
def find_robot(board):
    for i in range(3):
        for j in range(3):
            if board[i][j] == "X":
                return i, j

# Hàm kiểm tra xem trên board còn hạt bụi nào không
def is_goal(board):
    for row in board:
        if "1" in row:
            return False
    return True

# Thuật toán BFS - Approach 1 chuẩn chỉnh không bao giờ lỗi
def bfs_approach_1():
    # Frontier lưu: (tọa độ_robot_hiện_tại, danh_sách_hành_động)
    frontier = deque()
    start_pos = (0, 0)
    frontier.append((start_pos, []))

    # Reached lưu cặp: (tọa độ robot, số bụi còn lại)
    reached = set()
    start_dust = count_dust(initial_board)
    reached.add((start_pos, start_dust))
    
    logs = []

    while frontier:
        # Lấy nút ra khỏi hàng đợi
        current, actions = frontier.popleft()
        x, y = current

        # Ghi log nút hiện tại đang xét
        logs.append("==============================")
        logs.append(f"Current Node: {current}")

        # Lấy trạng thái bản đồ bụi toàn cục tương ứng với đường đi của Node này
        temp_board = get_board_after_actions(actions)

        # ==================================================
        # KIỂM TRA ĐÍCH KHI POP 
        # ==================================================
        if is_goal(temp_board):
            logs.append("Goal Reached!")
            return actions, logs

        # Thứ tự hướng đi chuẩn: UP -> DOWN -> LEFT -> RIGHT
        directions = [
            (-1, 0, "UP"),
            (1, 0, "DOWN"),
            (0, -1, "LEFT"),
            (0, 1, "RIGHT")
        ]

        # Vòng lặp sinh các nhánh con
        for dx, dy, action in directions:
            nx = x + dx
            ny = y + dy

            # Kiểm tra xem có đi kịch tường ma trận 3x3 không
            if 0 <= nx < 3 and 0 <= ny < 3:
                child_robot = (nx, ny)

                # Tính thử xem nếu đi vào ô này thì bản đồ còn bao nhiêu hạt bụi
                next_actions = actions + [action]
                next_board = get_board_after_actions(next_actions)
                child_dust = count_dust(next_board)

                # Kiểm tra trùng: Xét cả vị trí robot và số bụi còn lại
                if (child_robot, child_dust) not in reached:
                    reached.add((child_robot, child_dust))

                    # Ghi nhận log sinh nút con ra giao diện
                    logs.append(f"Generate {action} -> {child_robot}")
                    
                    # Nếu ô mới di chuyển tới có bụi ở bước trước đó thì báo Clean
                    if temp_board[nx][ny] == "1":
                        logs.append(f"Clean Dust at {child_robot}")

                    # Thêm nút con vào cuối hàng đợi
                    frontier.append((child_robot, next_actions))

                    # Gom danh sách tọa độ trong frontier để hiển thị log chữ
                    frontier_nodes = []
                    for node in frontier:
                        frontier_nodes.append(node[0])
                    logs.append(f"Frontier Add: {frontier_nodes}")

    return [], ["No Solution"]