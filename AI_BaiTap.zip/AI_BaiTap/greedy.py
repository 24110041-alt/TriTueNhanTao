import copy
import heapq

START_BOARD = [
    ["X", "1", "1"],
    ["0", "1", "0"],
    ["0", "0", "0"]
]

class NodeGreedy:
    def __init__(self, board, parent=None, action=None, path_cost=0):
        self.board = board
        self.parent = parent
        self.action = action
        self.path_cost = path_cost  # Lưu g(n) để tính tổng chi phí khi kết thúc
        self.h_cost = self.tinh_heuristic_manhattan_gan_nhat()  # f(n) = h(n)

    def tinh_heuristic_manhattan_gan_nhat(self):
        r_robot, c_robot = tim_vi_tri_robot(self.board)
        distances = []

        for r in range(3):
            for c in range(3):
                if self.board[r][c] == "1":
                    # Khoảng cách Manhattan: |x1 - x2| + |y1 - y2|
                    d = abs(r_robot - r) + abs(c_robot - c)
                    distances.append(d)

        if len(distances) == 0:
            return 0

        return min(distances)  # Lao tới bụi gần nhất!

    def __lt__(self, other):
        return self.h_cost < other.h_cost

def tim_vi_tri_robot(board):
    for r in range(3):
        for c in range(3):
            if board[r][c] == "X": return r, c
    return 0, 0

def kiem_tra_dich(board):
    for r in range(3):
        for c in range(3):
            if board[r][c] == "1": return False
    return True

def sinh_node_con_greedy(node):
    cac_con = []
    r, c = tim_vi_tri_robot(node.board)
    huong_di = [('LEFT', 0, -1), ('RIGHT', 0, 1), ('DOWN', 1, 0), ('UP', -1, 0)]
    
    for hanh_dong, dr, dc in huong_di:
        new_r, new_c = r + dr, c + dc
        if 0 <= new_r < 3 and 0 <= new_c < 3:
            o_sap_di = node.board[new_r][new_c]
            
            try:
                gia_tri_so = int(o_sap_di)
            except ValueError:
                gia_tri_so = 0
                
            board_moi = copy.deepcopy(node.board)
            board_moi[r][c] = "0"
            board_moi[new_r][new_c] = "X"
            
            chi_phi_g_moi = node.path_cost + gia_tri_so
            cac_con.append(NodeGreedy(board_moi, node, hanh_dong, chi_phi_g_moi))
    return cac_con

def in_board_gon(board):
    r, c = tim_vi_tri_robot(board)
    so_rac = sum(row.count("1") for row in board)
    return f"Robot ở ({r},{c}) | Còn {so_rac} ô bụi"

def greedy_approach():
    actions = []
    all_logs = []
    
    all_logs.append(f"=====================================")
    all_logs.append(f"  GREEDY: LAO TỚI BỤI GẦN NHẤT [min]")
    all_logs.append(f"=====================================")
    
    goc = NodeGreedy(START_BOARD)
    all_logs.append(f"  Trạng thái gốc: {in_board_gon(goc.board)}")
    
    frontier = []
    stt_chen = 0
    heapq.heappush(frontier, (goc.h_cost, stt_chen, goc))
    
    # Sử dụng tập đóng reached 
    reached = set()
    
    while len(frontier) > 0:
        current_h, _, node = heapq.heappop(frontier)
        
        board_tuple = tuple(tuple(row) for row in node.board)
        if board_tuple in reached:
            continue
        reached.add(board_tuple)
        
        if kiem_tra_dich(node.board):
            all_logs.append(f"  ==> Đã dọn SẠCH BỤI!")
            
            curr = node
            while curr.parent is not None:
                actions.append(curr.action)
                curr = curr.parent
            actions.reverse()
            
            all_logs.append(f"\n >> THÀNH CÔNG: Đã tìm thấy đường đi!")
            all_logs.append(f" >> TỔNG CHI PHÍ THỰC TẾ: {node.path_cost}")
            return actions, all_logs
            
        cac_con = sinh_node_con_greedy(node)
        for con in cac_con:
            con_tuple = tuple(tuple(row) for row in con.board)
            
            if con_tuple not in reached:
                trung_frontier = False
                for _, _, f_node in frontier:
                    if con.board == f_node.board:
                        trung_frontier = True
                        break
                
                if not trung_frontier:
                    stt_chen += 1
                    heapq.heappush(frontier, (con.h_cost, stt_chen, con))
                    all_logs.append(f"  [h={con.h_cost}] Greedy mở rộng hướng {con.action} -> {in_board_gon(con.board)}")
                    
    all_logs.append(f" >> THẤT BẠI: Không tìm thấy đường đi sạch bụi.\n")
    return actions, all_logs