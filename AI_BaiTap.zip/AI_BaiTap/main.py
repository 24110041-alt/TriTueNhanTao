import tkinter as tk
import time

# ==================================================
# IMPORT ALGORITHMS
# ==================================================
from bfs1 import bfs_approach_1
from bfs2 import bfs_approach_2
from dfs1 import dfs_approach_1
from dfs2 import dfs_approach_2
from iddfs1 import iddfs_approach_1
from iddfs2 import iddfs_approach_2
from ucs import ucs_approach
from A_star import astar_approach  
from A_star1 import astar_1_approach  
from A_star2 import astar_2_approach
from greedy import greedy_approach

# ==================================================
# WINDOW
# ==================================================
root = tk.Tk()
root.title("AI Vacuum Cleaner Simulation")
root.geometry("1200x700")
root.configure(bg="white")

# ==================================================
# INITIAL BOARD
# ==================================================
initial_board = [
    ["X", "1", "1"],
    ["0", "1", "0"],
    ["0", "0", "0"]
]

# ==================================================
# LEFT MENU (HOÀN CHỈNH - CÓ THANH CUỘN CHỐNG MẤT NÚT)
# ==================================================
# 1. Tạo một container frame cố định bên trái
menu_container = tk.Frame(root, bg="#2c3e50", width=240)
menu_container.pack(side="left", fill="y")


scrollbar = tk.Scrollbar(menu_container, orient="vertical")
scrollbar.pack(side="right", fill="y")


canvas = tk.Canvas(menu_container, bg="#2c3e50", width=220, bd=0, highlightthickness=0, yscrollcommand=scrollbar.set)
canvas.pack(side="left", fill="both", expand=True)


scrollbar.config(command=canvas.yview)


left_frame = tk.Frame(canvas, bg="#2c3e50")


canvas_frame = canvas.create_window((0, 0), window=left_frame, anchor="nw")


def configure_scroll_region(event):
    canvas.configure(scrollregion=canvas.bbox("all"))
left_frame.bind("<Configure>", configure_scroll_region)


def justify_width(event):
    canvas.itemconfig(canvas_frame, width=event.width)
canvas.bind("<Configure>", justify_width)


def _on_mousewheel(event):
    canvas.yview_scroll(int(-1*(event.delta/120)), "units")
canvas.bind_all("<MouseWheel>", _on_mousewheel)


# TITLE FOR MENU 
menu_title = tk.Label(
    left_frame,
    text="ALGORITHMS",
    font=("Arial", 14, "bold"),
    bg="#2c3e50",
    fg="white"
)
menu_title.pack(pady=20)

# ==================================================
# RIGHT ACTIVITY
# ==================================================
right_frame = tk.Frame(
    root,
    bg="#ecf0f1",
    width=300
)
right_frame.pack(
    side="right",
    fill="y"
)

# ==================================================
# CENTER FRAME
# ==================================================
center_frame = tk.Frame(
    root,
    bg="white"
)
center_frame.pack(
    side="left",
    fill="both",
    expand=True
)

# ==================================================
# BOTTOM SOLUTION
# ==================================================
bottom_frame = tk.Frame(
    center_frame,
    bg="#bdc3c7",
    height=120
)
bottom_frame.pack(
    side="bottom",
    fill="x"
)

# ==================================================
# TITLE
# ==================================================
title = tk.Label(
    center_frame,
    text="AI VACUUM CLEANER SIMULATION",
    font=("Arial", 24, "bold"),
    bg="white"
)
title.pack(pady=20)

# ==================================================
# DEMO TITLE
# ==================================================
demo_title = tk.Label(
    center_frame,
    text="DEMO AREA",
    font=("Arial", 18, "bold"),
    bg="white"
)
demo_title.pack()

# ==================================================
# GRID FRAME
# ==================================================
grid_frame = tk.Frame(
    center_frame,
    bg="white"
)
grid_frame.pack(pady=20)

# ==================================================
# CREATE GRID
# ==================================================
cells = []
for i in range(3):
    row = []
    for j in range(3):
        cell = tk.Label(
            grid_frame,
            text="",
            font=("Arial", 28, "bold"),
            width=4,
            height=2,
            borderwidth=2,
            relief="solid"
        )
        cell.grid(
            row=i,
            column=j,
            padx=5,
            pady=5
        )
        row.append(cell)
    cells.append(row)

# ==================================================
# LEGEND
# ==================================================
legend_frame = tk.Frame(
    center_frame,
    bg="white"
)
legend_frame.pack(pady=10)

robot_legend = tk.Label(
    legend_frame,
    text=" X = Vacuum Cleaner ",
    font=("Arial", 12, "bold"),
    bg="#f1c40f"
)
robot_legend.grid(row=0, column=0, padx=10)

dust_legend = tk.Label(
    legend_frame,
    text=" 1 = Dust ",
    font=("Arial", 12, "bold"),
    bg="#e74c3c",
    fg="white"
)
dust_legend.grid(row=0, column=1, padx=10)

clean_legend = tk.Label(
    legend_frame,
    text=" 0 = Clean ",
    font=("Arial", 12, "bold"),
    bg="#ecf0f1"
)
clean_legend.grid(row=0, column=2, padx=10)

# ==================================================
# UPDATE GRID
# ==================================================
def update_grid(board):
    for i in range(3):
        for j in range(3):
            value = board[i][j]
            color = "white"

            if value == "X":
                color = "#f1c40f"
            elif value == "1":
                color = "#e74c3c"
            elif value == "0":
                color = "#ecf0f1"

            cells[i][j].config(
                text=value,
                bg=color
            )
    root.update()

# ==================================================
# ACTIVITY TITLE
# ==================================================
log_title = tk.Label(
    right_frame,
    text="ACTIVITY",
    font=("Arial", 18, "bold"),
    bg="#ecf0f1"
)
log_title.pack(pady=20)

# ==================================================
# ACTIVITY BOX
# ==================================================
log_box = tk.Text(
    right_frame,
    width=35,
    height=30,
    font=("Arial", 11)
)
log_box.pack(padx=10)

# ==================================================
# SOLUTION TITLE
# ==================================================
solution_title = tk.Label(
    bottom_frame,
    text="FINAL SOLUTION",
    font=("Arial", 16, "bold"),
    bg="#bdc3c7"
)
solution_title.pack(pady=10)

# ==================================================
# SOLUTION LABEL
# ==================================================
solution_label = tk.Label(
    bottom_frame,
    text="Waiting...",
    font=("Arial", 14),
    bg="#bdc3c7"
)
solution_label.pack()

# ==================================================
# RUN BFS 1
# ==================================================
def run_bfs1():
    # Xóa sạch chữ ở bảng Activity bên phải trước khi chạy
    log_box.delete(1.0, tk.END)

    # Đặt lại ma trận ban đầu cho giao diện
    board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    update_grid(board)

    # Gọi thuật toán từ file bfs1.py
    actions, logs = bfs_approach_1()

    # Hiển thị log chữ chạy từ từ ở khung ACTIVITY
    for log in logs:
        log_box.insert(tk.END, log + "\n")
        log_box.see(tk.END)
        root.update()
        time.sleep(0.2)

    # Chạy hoạt ảnh Robot di chuyển trên lưới DEMO AREA
    for action in actions:
        # Tìm vị trí robot hiện tại trên lưới
        robot_x = 0
        robot_y = 0
        for i in range(3):
            for j in range(3):
                if board[i][j] == "X":
                    robot_x = i
                    robot_y = j

        # Tính toán ô mới dựa trên hướng đi
        new_x = robot_x
        new_y = robot_y

        if action == "UP": new_x -= 1
        elif action == "DOWN": new_x += 1
        elif action == "LEFT": new_y -= 1
        elif action == "RIGHT": new_y += 1

        # Xóa vị trí cũ, hút bụi ô mới và đặt robot vào ô mới
        board[robot_x][robot_y] = "0"
        if board[new_x][new_y] == "1":
            board[new_x][new_y] = "0"
        board[new_x][new_y] = "X"

        # Cập nhật lại màu sắc lưới ô vuông trên giao diện
        update_grid(board)
        root.update()
        time.sleep(0.8)

    # Hiển thị kết quả chuỗi mũi tên ở dưới cùng góc FINAL SOLUTION
    solution_label.config(text=" → ".join(actions))

# ==================================================
# RUN BFS 2
# ==================================================
def run_bfs():
    # CLEAR LOG
    log_box.delete(1.0, tk.END)

    # RESET BOARD
    board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    update_grid(board)

    # GET BFS RESULT
    actions, logs = bfs_approach_2()

    # SHOW LOGS
    for log in logs:
        log_box.insert(
            tk.END,
            log + "\n"
        )
        log_box.see(tk.END)
        root.update()
        time.sleep(0.2)

    # RUN ANIMATION
    for action in actions:
        # FIND ROBOT
        robot_x = 0
        robot_y = 0
        for i in range(3):
            for j in range(3):
                if board[i][j] == "X":
                    robot_x = i
                    robot_y = j

        # NEW POSITION
        new_x = robot_x
        new_y = robot_y

        # MOVE
        if action == "UP":
            new_x -= 1
        elif action == "DOWN":
            new_x += 1
        elif action == "LEFT":
            new_y -= 1
        elif action == "RIGHT":
            new_y += 1

        # OLD CELL CLEAN
        board[robot_x][robot_y] = "0"

        # CLEAN DUST
        if board[new_x][new_y] == "1":
            board[new_x][new_y] = "0"

        # MOVE ROBOT
        board[new_x][new_y] = "X"

        # UPDATE GRID
        update_grid(board)
        root.update()
        time.sleep(0.8)

    # FINAL SOLUTION
    solution_label.config(
        text=" → ".join(actions)
    )

# ==================================================
# RUN DFS 1
# ==================================================
def run_dfs1():
    # CLEAR ACTIVITY
    log_box.delete(1.0, tk.END)

    # RESET BOARD
    board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    update_grid(board)

    # RUN DFS
    actions, logs = dfs_approach_1()

    # SHOW LOGS
    for log in logs:
        log_box.insert(
            tk.END,
            log + "\n"
        )
        log_box.see(tk.END)
        root.update()
        time.sleep(0.2)

    # ANIMATION
    for action in actions:
        # FIND ROBOT
        robot_x = 0
        robot_y = 0
        for i in range(3):
            for j in range(3):
                if board[i][j] == "X":
                    robot_x = i
                    robot_y = j

        # MOVE
        new_x = robot_x
        new_y = robot_y

        if action == "UP":
            new_x -= 1
        elif action == "DOWN":
            new_x += 1
        elif action == "LEFT":
            new_y -= 1
        elif action == "RIGHT":
            new_y += 1

        # REMOVE OLD ROBOT
        board[robot_x][robot_y] = "0"

        # CLEAN DUST
        if board[new_x][new_y] == "1":
            board[new_x][new_y] = "0"

        # NEW POSITION
        board[new_x][new_y] = "X"

        # UPDATE GUI
        update_grid(board)
        root.update()
        time.sleep(0.8)

    # FINAL SOLUTION
    solution_label.config(
        text=" → ".join(actions)
    )

# ==================================================
# RUN DFS 2 
# ==================================================
def run_dfs2():
    # CLEAR ACTIVITY
    log_box.delete(1.0, tk.END)

    # RESET BOARD
    board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    update_grid(board)

    # RUN DFS 2
    actions, logs = dfs_approach_2()

    # SHOW LOGS
    for log in logs:
        log_box.insert(
            tk.END,
            log + "\n"
        )
        log_box.see(tk.END)
        root.update()
        time.sleep(0.2)

    # ANIMATION
    for action in actions:
        # FIND ROBOT
        robot_x = 0
        robot_y = 0
        for i in range(3):
            for j in range(3):
                if board[i][j] == "X":
                    robot_x = i
                    robot_y = j

        # MOVE
        new_x = robot_x
        new_y = robot_y

        if action == "UP":
            new_x -= 1
        elif action == "DOWN":
            new_x += 1
        elif action == "LEFT":
            new_y -= 1
        elif action == "RIGHT":
            new_y += 1

        # REMOVE OLD ROBOT
        board[robot_x][robot_y] = "0"

        # CLEAN DUST
        if board[new_x][new_y] == "1":
            board[new_x][new_y] = "0"

        # NEW POSITION
        board[new_x][new_y] = "X"

        # UPDATE GUI
        update_grid(board)
        root.update()
        time.sleep(0.8)

    # FINAL SOLUTION
    solution_label.config(
        text=" → ".join(actions)
    )

# ==================================================
# RUN IDDFS 1
# ==================================================
def run_iddfs1():
    # Xóa sạch chữ ở bảng Activity bên phải trước khi chạy
    log_box.delete(1.0, tk.END)

    # Đặt lại ma trận ban đầu cho giao diện
    board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    update_grid(board)

    # Gọi thuật toán IDDFS từ file iddfs1.py
    actions, logs = iddfs_approach_1()

    # Hiển thị log chữ chạy từ từ ở khung ACTIVITY
    for log in logs:
        log_box.insert(tk.END, log + "\n")
        log_box.see(tk.END)
        root.update()
        time.sleep(0.2)

    # Chạy hoạt ảnh Robot di chuyển trên lưới DEMO AREA
    for action in actions:
        # Tìm vị trí robot hiện tại trên lưới
        robot_x = 0
        robot_y = 0
        for i in range(3):
            for j in range(3):
                if board[i][j] == "X":
                    robot_x = i
                    robot_y = j

        # Tính toán ô mới dựa trên hướng đi
        new_x = robot_x
        new_y = robot_y

        if action == "UP": new_x -= 1
        elif action == "DOWN": new_x += 1
        elif action == "LEFT": new_y -= 1
        elif action == "RIGHT": new_y += 1

        # Xóa vị trí cũ, hút bụi ô mới và đặt robot vào ô mới
        board[robot_x][robot_y] = "0"
        if board[new_x][new_y] == "1":
            board[new_x][new_y] = "0"
        board[new_x][new_y] = "X"

        # Cập nhật lại màu sắc lưới ô vuông trên giao diện
        update_grid(board)
        root.update()
        time.sleep(0.8)

    # Hiển thị kết quả chuỗi mũi tên ở dưới cùng góc FINAL SOLUTION
    solution_label.config(text=" → ".join(actions))

# ==================================================
# RUN IDDFS 2
# ==================================================
def run_iddfs2(): 
    log_box.delete(1.0, tk.END)

    board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    update_grid(board)

    # Gọi đúng hàm IDDFS cách 2 bằng Stack
    actions, logs = iddfs_approach_2()  

    # SHOW LOGS
    for log in logs:
        log_box.insert(tk.END, log + "\n")
        log_box.see(tk.END)
        root.update()
        time.sleep(0.1)

    # ANIMATION
    for action in actions:
        robot_x, robot_y = 0, 0
        for i in range(3):
            for j in range(3):
                if board[i][j] == "X":
                    robot_x, robot_y = i, j

        new_x, new_y = robot_x, robot_y
        if action == "UP": new_x -= 1
        elif action == "DOWN": new_x += 1
        elif action == "LEFT": new_y -= 1
        elif action == "RIGHT": new_y += 1

        board[robot_x][robot_y] = "0"
        if board[new_x][new_y] == "1":
            board[new_x][new_y] = "0"
        board[new_x][new_y] = "X"

        update_grid(board)
        root.update()
        time.sleep(0.8)

    solution_label.config(text=" → ".join(actions))

# ==================================================
# RUN UCS
# ==================================================
def run_ucs():
    log_box.delete(1.0, tk.END)
    board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    update_grid(board)

    actions, logs = ucs_approach()

    for log in logs:
        log_box.insert(tk.END, log + "\n")
        log_box.see(tk.END)
        root.update()
        time.sleep(0.1)

    for action in actions:
        robot_x, robot_y = 0, 0
        for i in range(3):
            for j in range(3):
                if board[i][j] == "X":
                    robot_x, robot_y = i, j

        new_x, new_y = robot_x, robot_y
        if action == "UP": new_x -= 1
        elif action == "DOWN": new_x += 1
        elif action == "LEFT": new_y -= 1
        elif action == "RIGHT": new_y += 1

        board[robot_x][robot_y] = "0"
        if board[new_x][new_y] == "1":
            board[new_x][new_y] = "0"
        board[new_x][new_y] = "X"

        update_grid(board)
        root.update()
        time.sleep(0.8)

    solution_label.config(text=" → ".join(actions))

# ==================================================
# RUN A STAR
# ==================================================
def run_astar():
    log_box.delete(1.0, tk.END)
    board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    update_grid(board)

    actions, logs = astar_approach()

    for log in logs:
        log_box.insert(tk.END, log + "\n")
        log_box.see(tk.END)
        root.update()
        time.sleep(0.1)

    for action in actions:
        robot_x, robot_y = 0, 0
        for i in range(3):
            for j in range(3):
                if board[i][j] == "X":
                    robot_x, robot_y = i, j

        new_x, new_y = robot_x, robot_y
        if action == "UP": new_x -= 1
        elif action == "DOWN": new_x += 1
        elif action == "LEFT": new_y -= 1
        elif action == "RIGHT": new_y += 1

        board[robot_x][robot_y] = "0"
        if board[new_x][new_y] == "1":
            board[new_x][new_y] = "0"
        board[new_x][new_y] = "X"

        update_grid(board)
        root.update()
        time.sleep(0.8)

   
    tong_chi_phi = 0
    for line in logs:
        if "TỔNG CHI PHÍ THẤP NHẤT" in line:
            tong_chi_phi = line.split(": ")[1]
            break
            
    solution_label.config(text=" → ".join(actions))

def run_astar1():
    log_box.delete(1.0, tk.END)
    board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    update_grid(board)

    # Gọi thuật toán từ file A_star1.py
    actions, logs = astar_1_approach()

    for log in logs:
        log_box.insert(tk.END, log + "\n")
        log_box.see(tk.END)
        root.update()
        time.sleep(0.1)

    for action in actions:
        robot_x, robot_y = 0, 0
        for i in range(3):
            for j in range(3):
                if board[i][j] == "X":
                    robot_x, robot_y = i, j

        new_x, new_y = robot_x, robot_y
        if action == "UP": new_x -= 1
        elif action == "DOWN": new_x += 1
        elif action == "LEFT": new_y -= 1
        elif action == "RIGHT": new_y += 1

        board[robot_x][robot_y] = "0"
        if board[new_x][new_y] == "1":
            board[new_x][new_y] = "0"
        board[new_x][new_y] = "X"

        update_grid(board)
        root.update()
        time.sleep(0.8)

    # Đếm chi phí thực tế cho Cách 1 từ logs
    tong_chi_phi = 0
    for line in logs:
        if "Chi phí thực tế" in line:
            tong_chi_phi = line.split(": ")[1]
            break
            
    solution_label.config(text=" → ".join(actions) )

# ==================================================
# RUN A STAR 2 (Cách 3: C3 = 1 + 4 Lai Số ô bụi & Dãy ngược)
# ==================================================
def run_astar2():
    log_box.delete(1.0, tk.END)
    board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    update_grid(board)

    # Gọi thuật toán từ file A_star2.py
    actions, logs = astar_2_approach()

    for log in logs:
        log_box.insert(tk.END, log + "\n")
        log_box.see(tk.END)
        root.update()
        time.sleep(0.1)

    for action in actions:
        robot_x, robot_y = 0, 0
        for i in range(3):
            for j in range(3):
                if board[i][j] == "X":
                    robot_x, robot_y = i, j

        new_x, new_y = robot_x, robot_y
        if action == "UP": new_x -= 1
        elif action == "DOWN": new_x += 1
        elif action == "LEFT": new_y -= 1
        elif action == "RIGHT": new_y += 1

        board[robot_x][robot_y] = "0"
        if board[new_x][new_y] == "1":
            board[new_x][new_y] = "0"
        board[new_x][new_y] = "X"

        update_grid(board)
        root.update()
        time.sleep(0.8)

    # Đếm chi phí thực tế cho Cách 3 từ logs
    tong_chi_phi = 0
    for line in logs:
        if "Chi phí thực tế" in line:
            tong_chi_phi = line.split(": ")[1]
            break
            
    solution_label.config(text=" → ".join(actions))
# ==================================================
# RUN GREEDY
# ==================================================
def run_greedy():
    log_box.delete(1.0, tk.END)
    board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    update_grid(board)

    actions, logs = greedy_approach()

    for log in logs:
        log_box.insert(tk.END, log + "\n")
        log_box.see(tk.END)
        root.update()
        time.sleep(0.1)

    for action in actions:
        robot_x, robot_y = 0, 0
        for i in range(3):
            for j in range(3):
                if board[i][j] == "X":
                    robot_x, robot_y = i, j

        new_x, new_y = robot_x, robot_y
        if action == "UP": new_x -= 1
        elif action == "DOWN": new_x += 1
        elif action == "LEFT": new_y -= 1
        elif action == "RIGHT": new_y += 1

        board[robot_x][robot_y] = "0"
        if board[new_x][new_y] == "1":
            board[new_x][new_y] = "0"
        board[new_x][new_y] = "X"

        update_grid(board)
        root.update()
        time.sleep(0.8)

    tong_chi_phi = 0
    for line in logs:
        if "TỔNG CHI PHÍ THỰC TẾ" in line:
            tong_chi_phi = line.split(": ")[1]
            break
            
    solution_label.config(text=" → ".join(actions) + f"  (Tổng chi phí = {tong_chi_phi})")

# ==================================================
# BUTTONS IN LEFT MENU
# ==================================================
# 1. BFS 1 BUTTON 
bfs1_button = tk.Button(
    left_frame,
    text="BFS - Approach 1",
    command=run_bfs1,         
    font=("Arial", 12),
    width=18,
    height=2,
    bg="#2980b9",           
    fg="white"
)
bfs1_button.pack(pady=10)

# 2. BFS 2 BUTTON 
bfs_button = tk.Button(
    left_frame,
    text="BFS - Approach 2",
    command=run_bfs,
    font=("Arial", 12),
    width=18,
    height=2,
    bg="#3498db",
    fg="white"
)
bfs_button.pack(pady=10)

# 3. DFS 1 BUTTON
dfs1_button = tk.Button(
    left_frame,
    text="DFS - Approach 1",
    command=run_dfs1,
    font=("Arial", 12),
    width=18,
    height=2,
    bg="#27ae60",
    fg="white"
)
dfs1_button.pack(pady=10)

# 4. DFS 2 BUTTON
dfs2_button = tk.Button(
    left_frame,
    text="DFS - Approach 2",
    command=run_dfs2,
    font=("Arial", 12),
    width=18,
    height=2,
    bg="#e67e22",
    fg="white"
)
dfs2_button.pack(pady=10)

# 5. IDDFS 1 BUTTON
iddfs1_button = tk.Button(
    left_frame,
    text="IDDFS - Approach 1",  
    command=run_iddfs1,          
    font=("Arial", 12),
    width=18,
    height=2,
    bg="#9b59b6",                
    fg="white"
)
iddfs1_button.pack(pady=10)
# 6. IDDFS 2 BUTTON 
iddfs2_button = tk.Button(
    left_frame,
    text="IDDFS - Approach 2",  
    command=run_iddfs2,         
    font=("Arial", 12),
    width=18,
    height=2,
    bg="#3498db",
    fg="white"
)
iddfs2_button.pack(pady=10)
#7. UCS BUTTON
ucs_button = tk.Button(
    left_frame,
    text="UCS Algorithm",
    command=run_ucs,
    font=("Arial", 12),
    width=18,
    height=2,
    bg="#e67e22",  
    fg="white"
)
ucs_button.pack(pady=10)
#8. A STAR BUTTON
astar_button = tk.Button(
    left_frame,
    text="A*- Approach 1",
    command=run_astar,
    font=("Arial", 12),
    width=18,
    height=2,
    bg="#9b59b6",  
    fg="white"
)
astar_button.pack(pady=10)
#9. A STAR 1 BUTTON (Cách 1: G1)
astar1_button = tk.Button(
    left_frame,
    text="A*- Approach 2",
    command=run_astar1,
    font=("Arial", 12),
    width=18,
    height=2,
    bg="#34495e",  
    fg="white"
)
astar1_button.pack(pady=10)

#10 A STAR 2 BUTTON (Cách 3: C3)
astar2_button = tk.Button(
    left_frame,
    text="A*- Approach 3 ",
    command=run_astar2,
    font=("Arial", 12),
    width=18,
    height=2,
    bg="#d35400",  
    fg="white"
)
astar2_button.pack(pady=10)
#11 GREEDY BUTTON
greedy_button = tk.Button(
    left_frame,
    text="Greedy Algorithm",
    command=run_greedy,
    font=("Arial", 12),
    width=18,
    height=2,
    bg="#1abc9c",  
    fg="white"
)
greedy_button.pack(pady=10)

update_grid(initial_board)

root.mainloop()