import copy

# ==================================================
# INITIAL BOARD
# ==================================================
initial_board = [
    ["X", "1", "1"],
    ["0", "1", "0"],
    ["0", "0", "0"]
]

# ==================================================
# ENCODE STATE TO TUPLE (Tối ưu hóa bộ nhớ và tốc độ check visited)
# ==================================================
def get_state_tuple(pos, board):
    return (pos, tuple(tuple(row) for row in board))

# ==================================================
# CHECK GOAL
# ==================================================
def is_goal(board):
    for row in board:
        if "1" in row:
            return False
    return True

# ==================================================
# DFS APPROACH 2 (OPTIMIZED)
# ==================================================
def dfs_approach_2():
    start_board = copy.deepcopy(initial_board)
    start_pos = (0, 0)

    # Stack lưu: (vị trí_hiện_tại, chuỗi_hành_động, ma_trận_tại_nút_đó)
    stack = []
    stack.append((start_pos, [], start_board))

    visited = set()
    logs = []

    while stack:
        current, actions, current_board = stack.pop()
        x, y = current

        # Lấy định danh trạng thái để kiểm tra trùng lặp
        state_id = get_state_tuple(current, current_board)

        if state_id in visited:
            logs.append("==============================")
            logs.append(f"Current Node: {current} (State Loop) -> Backtrack")
            continue
            
        visited.add(state_id)

        # ==========================================
        # LOG CURRENT NODE WHEN POPPED
        # ==========================================
        logs.append("==============================")
        logs.append(f"Current Node: {current}")

        # ==========================================
        # HÚT BỤI TẠI CHỖ VÀ ĐỒNG BỘ MA TRẬN NÚT HIỆN TẠI
        # ==========================================
        # Tạo một bản sao duy nhất tại đây để chuẩn bị sinh các nhánh con tiếp theo
        next_board = copy.deepcopy(current_board)
        
        if next_board[x][y] == "1":
            next_board[x][y] = "0"
            logs.append(f"Clean Dust at {current}")
        
        # Đảm bảo ô hiện tại hiển thị đúng vị trí Robot
        next_board[x][y] = "X"

        # Kiểm tra điều kiện ĐÍCH ngay sau khi dọn dẹp ô hiện tại
        if is_goal(next_board):
            logs.append("Goal Reached!")
            return actions, logs

        # ==========================================
        # THỨ TỰ ƯU TIÊN: DOWN → RIGHT → UP → LEFT
        # Đẩy vào Stack ngược lại: LEFT, UP, RIGHT, DOWN
        # ==========================================
        directions = [
            (0, -1, "LEFT"),
            (-1, 0, "UP"),
            (0, 1, "RIGHT"),
            (1, 0, "DOWN")
        ]

        moved = False
        for dx, dy, action in directions:
            nx = x + dx
            ny = y + dy

            if 0 <= nx < 3 and 0 <= ny < 3:
                child = (nx, ny)
                
                # Robot di chuyển sang ô mới, nghĩa là ô cũ (x, y) sẽ biến thành ô sạch '0'
                child_board = [row[:] for row in next_board]
                child_board[x][y] = "0"
                child_board[nx][ny] = "X"

                # Check nhanh xem trạng thái của nút con này đã nằm trong visited chưa
                child_state_id = get_state_tuple(child, child_board)

                if child_state_id not in visited:
                    logs.append(f"Go {action} -> {child}")
                    # Push vào Stack ma trận child_board đã được dịch chuyển đúng trạng thái
                    stack.append((child, actions + [action], child_board))
                    moved = True

        if not moved:
            logs.append("Dead End -> Preparing to Backtrack")

    return [], logs