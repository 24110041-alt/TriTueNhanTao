# Hàm tính Heuristic h(n): Số ô còn bụi trên bản đồ
def tinh_heuristic(board):
    count = 0
    for i in range(3):
        for j in range(3):
            if board[i][j] == "1":
                count += 1
    return count

# Tìm tọa độ (dòng, cột) của Robot 'X'
def tim_robot(board):
    for i in range(3):
        for j in range(3):
            if board[i][j] == "X":
                return i, j

# Sinh toàn bộ các trạng thái lân cận hợp lệ (LEFT, RIGHT, UP, DOWN)
# Đồng thời lưu lại chuỗi hành động đi kèm
def lay_trang_thai_ke_tiep(board, current_actions):
    moves = []
    r, c = tim_robot(board)
    directions = [(0, -1, "LEFT"), (0, 1, "RIGHT"), (-1, 0, "UP"), (1, 0, "DOWN")]
    
    for dr, dc, action in directions:
        nr, nc = r + dr, c + dc
        if 0 <= nr < 3 and 0 <= nc < 3:
            new_board = [row[:] for row in board]
            new_board[r][c] = "0"
            if new_board[nr][nc] == "1":
                new_board[nr][nc] = "0"
            new_board[nr][nc] = "X"
            
            # Cập nhật danh sách hành động tương ứng cho trạng thái mới này
            new_actions = current_actions + [action]
            moves.append((new_board, new_actions))
    return moves

# Kiểm tra xem bản đồ đã sạch bụi hoàn toàn chưa
def kiem_tra_sach_bui(board):
    for i in range(3):
        for j in range(3):
            if board[i][j] == "1":
                return False
    return True

# Hàm chạy thuật toán Local Beam Search 
def local_beam_search_approach(k=2):
    logs = []
    logs.append(f"--- BẮT ĐẦU GIẢI BẰNG LOCAL BEAM SEARCH (k = {k}) ---")
    
    # Bản đồ xuất phát ban đầu
    start_board = [
        ["X", "1", "1"],
        ["0", "1", "0"],
        ["0", "0", "0"]
    ]
    
    # 1. KHỞI TẠO: Current_State_set = {Sinh k trạng thái từ Start}
    # Vì bài toán cố định từ vị trí Start, ta khởi tạo tập ban đầu chứa trạng thái xuất phát này
    # Mỗi phần tử cấu trúc: (board, danh_sách_hành_động)
    current_state_set = [(start_board, [])]
    
    buoc = 1
    
    # 2. TRONG KHI (đúng)
    while True:
        logs.append(f"\n [VÒNG LẶP THỨ {buoc}] Đang quản lý {len(current_state_set)} trạng thái chùm:")
        for idx, (b, act) in enumerate(current_state_set):
            r, c = tim_robot(b)
            logs.append(f"  + Trạng thái {idx+1}: Robot đứng tại ({r}, {c}) | Còn {tinh_heuristic(b)} ô bụi")
            
        # Neighbor_States = rỗng
        neighbor_states = []
        
        # 2.1. SINH TRẠNG THÁI LÂN CẬN: VỚI MỖI State trong Current_State_set
        for board, actions in current_state_set:
            # Sinh tất cả các trạng thái lân cận của State và thêm vào Neighbor_States
            next_moves = lay_trang_thai_ke_tiep(board, actions)
            for next_board, next_actions in next_moves:
                neighbor_states.append((next_board, next_actions))
                
        logs.append(f"  ---> Đã sinh tổng cộng {len(neighbor_states)} trạng thái lân cận chùm")
        
        # 2.2. KIỂM TRA ĐÍCH: VỚI MỖI Neighbor trong Neighbor_States
        for neighbor_board, neighbor_actions in neighbor_states:
            # NẾU Neighbor == Goal -> TRẢ VỀ Neighbor (Tìm thấy đích, dừng ngay thuật toán)
            if kiem_tra_sach_bui(neighbor_board):
                logs.append("\n==========================================")
                logs.append("==> Đã tìm thấy đích (SẠCH BỤI hoàn toàn)!")
                logs.append(">> THÀNH CÔNG LOCAL BEAM SEARCH!")
                logs.append("==========================================")
                return neighbor_actions, logs
                
        # 2.3. LỰA CHỌN CHÙM (NẾU CHƯA TÌM THẤY ĐÍCH):
        # Sắp xếp Neighbor_States theo thứ tự giá trị hàm mục tiêu h tốt dần (h càng nhỏ càng tốt)
        neighbor_states.sort(key=lambda x: tinh_heuristic(x[0]))
        
        # Current_State_set = Lấy k trạng thái tốt nhất từ Neighbor_States đã sắp xếp
        # Nếu số lượng lân cận sinh ra ít hơn k, lấy toàn bộ lân cận
        current_state_set = neighbor_states[:k]
        
        # Điều kiện dừng an toàn: Nếu không sinh thêm được lân cận nào nữa
        if not current_state_set:
            logs.append("\Kết thúc: Không còn trạng thái lân cận nào để xét!")
            break
            
        buoc += 1
        
    return [], logs