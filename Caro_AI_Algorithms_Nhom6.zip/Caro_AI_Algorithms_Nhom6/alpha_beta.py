import tkinter as tk
from caro_base import CaroBase

class CaroAlphaBeta(CaroBase):
    def __init__(self, root):
        super().__init__(root, title="Thuật toán Alpha-Beta Pruning")

    def minimax_ab(self, depth, alpha, beta, is_maximizing):
        winner = self.check_winner()
        if winner == 'X': return 10 - depth
        if winner == 'O': return depth - 10
        if winner == 'Tie': return 0

        if is_maximizing:
            max_eval = -float('inf')
            for i in range(9):
                if self.board[i] == ' ':
                    self.board[i] = 'X'
                    eval_score = self.minimax_ab(depth + 1, alpha, beta, False)
                    self.board[i] = ' '
                    max_eval = max(max_eval, eval_score)
                    alpha = max(alpha, eval_score)
                    if beta <= alpha:
                        self.log(f"  [Cắt Tỉa] Node Max: beta({beta}) <= alpha({alpha})")
                        break # Cắt tỉa nhánh thừa
            return max_eval
        else:
            min_eval = float('inf')
            for i in range(9):
                if self.board[i] == ' ':
                    self.board[i] = 'O'
                    eval_score = self.minimax_ab(depth + 1, alpha, beta, True)
                    self.board[i] = ' '
                    min_eval = min(min_eval, eval_score)
                    beta = min(beta, eval_score)
                    if beta <= alpha:
                        self.log(f"  [Cắt Tỉa] Node Min: beta({beta}) <= alpha({alpha})")
                        break
            return min_eval

    def play_turn(self):
        winner = self.check_winner()
        if winner:
            self.result_label.config(text=f"Kết thúc: {winner if winner != 'Tie' else 'Hòa!'}", fg='green')
            return

        self.log(f"--- Đến lượt {self.turn} (Alpha-Beta) ---")
        best_score = -float('inf') if self.turn == 'X' else float('inf')
        move = -1
        
        for i in range(9):
            if self.board[i] == ' ':
                self.board[i] = self.turn
                score = self.minimax_ab(0, -float('inf'), float('inf'), self.turn == 'O')
                self.board[i] = ' '
                self.log(f" * Phân tích ô {i}: Điểm kỳ vọng {score}")
                
                if self.turn == 'X' and score > best_score:
                    best_score, move = score, i
                elif self.turn == 'O' and score < best_score:
                    best_score, move = score, i
        
        self.board[move] = self.turn
        self.buttons[move].config(text=self.turn, fg='blue' if self.turn == 'X' else 'red')
        self.log(f">> Quyết định chốt ô {move} (Điểm: {best_score})\n")
        
        self.turn = 'O' if self.turn == 'X' else 'X'
        self.root.after(800, self.play_turn)

if __name__ == "__main__":
    root = tk.Tk()
    app = CaroAlphaBeta(root)
    root.mainloop()