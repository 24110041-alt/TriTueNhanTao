import copy

START_BOARD = [
    ["X", "1", "1"],
    ["0", "1", "0"],
    ["0", "0", "0"]
]

class NodeStack:
    def __init__(self, board, parent=None, action=None, depth=0, name="S"):
        self.board = board
        self.parent = parent
        self.action = action
        self.depth = depth
        self.name = name

def tim_vi_tri_robot(board):
    for r in range(3):
        for c in range(3):
            if board[r][c] == "X": return r, c
    return 0, 0

def kiem_tra_dich(board):
    for r in range(3):
        for c in range(3):
            if board[r][c] == "1": return False
    return True

def bi_lap_vong(node):
    cha = node.parent
    while cha:
        if cha.board == node.board: return True
        cha = cha.parent
    return False

def sinh_node_con_stack(node):
    cac_con = []
    r, c = tim_vi_tri_robot(node.board)
    huong_di = [('LEFT', 0, -1), ('RIGHT', 0, 1), ('DOWN', 1, 0), ('UP', -1, 0)]
    
    for idx, (hanh_dong, dr, dc) in enumerate(huong_di, start=1):
        new_r, new_c = r + dr, c + dc
        if 0 <= new_r < 3 and 0 <= new_c < 3:
            board_moi = copy.deepcopy(node.board)
            board_moi[r][c] = "0"
            board_moi[new_r][new_c] = "X"
            
            if node.name == "S":
                ten_node = chr(64 + idx)
            else:
                ten_node = f"{node.name}{idx}"
                
            cac_con.append(NodeStack(board_moi, node, hanh_dong, node.depth + 1, name=ten_node))
    return cac_con

def in_board_gon(board):
    r, c = tim_vi_tri_robot(board)
    so_rac = sum(row.count("1") for row in board)
    return f"Robot({r},{c}) | Còn {so_rac} bụi"

def dls_stack(goc, limit, logs):
    frontier = [goc]
    reached = []
    co_cutoff = False
    
    while len(frontier) > 0:
        node = frontier.pop()
        reached.append(node)
        
        if kiem_tra_dich(node.board):
            logs.append(f"  ==> Đã dọn SẠCH BỤI ở độ sâu tầng {node.depth}!")
            return node
            
        if node.depth >= limit:
            co_cutoff = True
            continue
            
        cac_con_sinh_ra = sinh_node_con_stack(node)
        # Đảo ngược để nạp Stack theo đúng chuẩn LIFO
        for con in reversed(cac_con_sinh_ra):
            if bi_lap_vong(con):
                logs.append(f"  [Tầng {con.depth}] Thử {con.action} -> Lặp (Bỏ)")
                continue
                
            trang_thai_da_duyet = False
            for r in reached:
                if con.board == r.board:
                    trang_thai_da_duyet = True
                    break
                    
            if not trang_thai_da_duyet:
                frontier.append(con)
                # ĐỒNG BỘ LOG GIỐNG IDDFS1
                logs.append(f"  [Tầng {con.depth}] IDDFS đi sâu xuống hướng {con.action} -> {in_board_gon(con.board)}")
                
    return "cutoff" if co_cutoff else None

def iddfs_approach_2():
    actions = []
    all_logs = []
    
    for depth_limit in range(6):
        all_logs.append(f"===============================")
        all_logs.append(f"  IDDFS: THỬ NGHIỆM GIỚI HẠN TẦNG L = {depth_limit}")
        all_logs.append(f"===============================")
        
        goc_ban_dau = NodeStack(START_BOARD, name="S")
        all_logs.append(f"  Trạng thái gốc: {in_board_gon(goc_ban_dau.board)}")
        
        logs_tang_nay = []
        kq = dls_stack(goc_ban_dau, depth_limit, logs_tang_nay)
        all_logs.extend(logs_tang_nay)
        
        if kq != "cutoff" and kq is not None:
            curr = kq
            while curr.parent is not None:
                actions.append(curr.action)
                curr = curr.parent
            actions.reverse()
            all_logs.append(f"\n >> THÀNH CÔNG: Tìm thấy đường đi ngắn nhất ở giới hạn L = {depth_limit}!")
            break
        else:
            all_logs.append(f" >> THẤT BẠI: Giới hạn L = {depth_limit} không đủ sâu để sạch bụi.\n")
            
    return actions, all_logs